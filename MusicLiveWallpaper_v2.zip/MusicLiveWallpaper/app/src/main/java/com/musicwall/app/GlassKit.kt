package com.musicwall.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

/** Colors used by the liquid-glass UI. */
object Pal {
    val violet = Color.rgb(124, 92, 255)
    val cyan = Color.rgb(64, 196, 255)
    val pink = Color.rgb(255, 92, 160)
    val amber = Color.rgb(255, 176, 80)
    val mint = Color.rgb(60, 230, 160)
    val bgTop = Color.rgb(10, 9, 28)
    val bgBottom = Color.rgb(22, 10, 44)
}

private fun withAlpha(c: Int, a: Int): Int = (c and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)

/** Squash-and-stretch press feedback that does not swallow the click. */
fun View.jellyPress() {
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN ->
                v.animate().scaleX(0.965f).scaleY(0.93f).setDuration(110)
                    .setInterpolator(DecelerateInterpolator()).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                v.animate().scaleX(1f).scaleY(1f).setDuration(420)
                    .setInterpolator(OvershootInterpolator(3.4f)).start()
        }
        false
    }
}

// ======================================================================
// Animated backdrop: gradient + soft glows + glossy beads. It also keeps a
// low-resolution copy of itself that glass panels use as their frosted layer.
// ======================================================================

class LiquidBackdrop(ctx: Context) : View(ctx), Choreographer.FrameCallback {

    companion object {
        var instance: LiquidBackdrop? = null
        val glass = ArrayList<View>()
        private const val BLUR_DIV = 8f
    }

    private class Orb(
        val ax: Float, val ay: Float, val ampX: Float, val ampY: Float,
        val sp: Float, val ph: Float, val r: Float, val col: Int, val bead: Boolean
    ) {
        var ox = 0f
        var oy = 0f
    }

    private val orbs = ArrayList<Orb>()
    private val bgPaint = Paint()
    private val blobPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val beadPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val ripplePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val blobShaders = HashMap<Int, Shader>()
    private val beadShaders = HashMap<Int, Shader>()
    private var bgShader: Shader? = null

    var blur: Bitmap? = null
        private set
    private var blurCanvas: Canvas? = null

    private var t = 0f
    private var lastNs = 0L
    private var touchX = 0f
    private var touchY = 0f
    private var touching = false
    private var attached = false

    private class Ripple(val x: Float, val y: Float, val born: Long)

    private val ripples = ArrayList<Ripple>()

    init {
        val cols = intArrayOf(Pal.violet, Pal.cyan, Pal.pink, Pal.amber, Pal.mint)
        // big soft glows
        for (i in 0 until 5) {
            orbs.add(
                Orb(
                    0.15f + 0.7f * ((i * 37) % 100) / 100f, 0.1f + 0.8f * ((i * 53) % 100) / 100f,
                    0.18f, 0.12f, 0.18f + i * 0.05f, i * 1.7f, 0.55f + 0.1f * (i % 3), cols[i % cols.size], false
                )
            )
        }
        // crisp glossy beads (these are what the glass panels blur)
        for (i in 0 until 9) {
            orbs.add(
                Orb(
                    0.1f + 0.8f * ((i * 61 + 13) % 100) / 100f, 0.08f + 0.84f * ((i * 29 + 7) % 100) / 100f,
                    0.10f + 0.04f * (i % 3), 0.08f + 0.03f * (i % 4), 0.25f + i * 0.037f, i * 0.9f,
                    0.045f + 0.03f * (i % 4), cols[(i + 2) % cols.size], true
                )
            )
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        instance = this
        attached = true
        lastNs = 0L
        Choreographer.getInstance().postFrameCallback(this)
    }

    override fun onDetachedFromWindow() {
        attached = false
        if (instance === this) instance = null
        Choreographer.getInstance().removeFrameCallback(this)
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        if (w <= 0 || h <= 0) return
        bgShader = LinearGradient(0f, 0f, 0f, h.toFloat(), Pal.bgTop, Pal.bgBottom, Shader.TileMode.CLAMP)
        val bw = max(2, (w / BLUR_DIV).toInt())
        val bh = max(2, (h / BLUR_DIV).toInt())
        val b = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        blur = b
        blurCanvas = Canvas(b)
    }

    fun touch(e: MotionEvent) {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                touching = true
                touchX = e.rawX - locX()
                touchY = e.rawY - locY()
                ripples.add(Ripple(touchX, touchY, SystemClock.uptimeMillis()))
                if (ripples.size > 5) ripples.removeAt(0)
            }
            MotionEvent.ACTION_MOVE -> {
                touchX = e.rawX - locX()
                touchY = e.rawY - locY()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> touching = false
        }
    }

    private fun locX(): Float {
        val l = IntArray(2)
        getLocationOnScreen(l)
        return l[0].toFloat()
    }

    private fun locY(): Float {
        val l = IntArray(2)
        getLocationOnScreen(l)
        return l[1].toFloat()
    }

    override fun doFrame(frameTimeNanos: Long) {
        if (!attached) return
        val dt = if (lastNs == 0L) 0.016f else ((frameTimeNanos - lastNs) / 1e9f).coerceIn(0.001f, 0.05f)
        lastNs = frameTimeNanos
        t += dt
        step()
        redrawBlur()
        invalidate()
        for (v in glass) v.invalidate()
        Choreographer.getInstance().postFrameCallback(this)
    }

    private var beat = 0f

    private fun step() {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f) return
        // pseudo beat while music is playing
        if (MusicState.playing) {
            val ph = (t * 1.9f) % 1f
            beat = (1f - ph).pow(4f)
        } else {
            beat *= 0.9f
        }
        for (o in orbs) {
            val bx = (o.ax + sin(t * o.sp + o.ph) * o.ampX) * w
            val by = (o.ay + cos(t * o.sp * 0.8f + o.ph * 1.3f) * o.ampY) * h
            var tx = 0f
            var ty = 0f
            if (touching) {
                val dx = touchX - bx
                val dy = touchY - by
                val d = kotlin.math.sqrt(dx * dx + dy * dy)
                val pull = (1f - d / (0.65f * w)).coerceIn(0f, 1f)
                val k = pull * pull * 0.45f
                tx = dx * k
                ty = dy * k
            }
            o.ox += (tx - o.ox) * 0.09f
            o.oy += (ty - o.oy) * 0.09f
        }
    }

    private fun blobShader(col: Int): Shader = blobShaders.getOrPut(col) {
        RadialGradient(0f, 0f, 1f, intArrayOf(withAlpha(col, 150), withAlpha(col, 0)), floatArrayOf(0f, 1f), Shader.TileMode.CLAMP)
    }

    private fun beadShader(col: Int): Shader = beadShaders.getOrPut(col) {
        val light = Color.rgb(
            min(255, Color.red(col) + 90), min(255, Color.green(col) + 90), min(255, Color.blue(col) + 90)
        )
        val dark = Color.rgb(Color.red(col) / 3, Color.green(col) / 3, Color.blue(col) / 3)
        RadialGradient(
            -0.35f, -0.4f, 1.5f,
            intArrayOf(withAlpha(light, 245), withAlpha(col, 235), withAlpha(dark, 235)),
            floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
        )
    }

    private fun drawScene(c: Canvas, w: Float, h: Float) {
        bgPaint.shader = bgShader
        c.drawRect(0f, 0f, w, h, bgPaint)
        val pulse = 1f + 0.06f * beat
        for (o in orbs) {
            val x = (o.ax + sin(t * o.sp + o.ph) * o.ampX) * w + o.ox
            val y = (o.ay + cos(t * o.sp * 0.8f + o.ph * 1.3f) * o.ampY) * h + o.oy
            val r = o.r * min(w, h) * pulse
            c.save()
            c.translate(x, y)
            if (!o.bead) {
                c.scale(r * 1.8f, r * 1.8f)
                blobPaint.shader = blobShader(o.col)
                c.drawCircle(0f, 0f, 1f, blobPaint)
            } else {
                c.scale(r, r)
                beadPaint.shader = beadShader(o.col)
                c.drawCircle(0f, 0f, 1f, beadPaint)
                rimPaint.strokeWidth = 2.2f / r
                rimPaint.color = withAlpha(Color.WHITE, 90)
                c.drawCircle(0f, 0f, 0.98f, rimPaint)
            }
            c.restore()
        }
        // touch ripples
        val now = SystemClock.uptimeMillis()
        val it = ripples.iterator()
        while (it.hasNext()) {
            val rp = it.next()
            val age = (now - rp.born) / 900f
            if (age >= 1f) {
                it.remove()
                continue
            }
            ripplePaint.strokeWidth = max(1f, min(w, h) * 0.012f * (1f - age))
            ripplePaint.color = withAlpha(Color.WHITE, ((1f - age) * (1f - age) * 150f).toInt())
            c.drawCircle(rp.x, rp.y, min(w, h) * (0.05f + age * 0.5f), ripplePaint)
        }
    }

    private fun redrawBlur() {
        val b = blur ?: return
        val bc = blurCanvas ?: return
        if (width <= 0) return
        bc.save()
        bc.scale(b.width / width.toFloat(), b.height / height.toFloat())
        drawScene(bc, width.toFloat(), height.toFloat())
        bc.restore()
    }

    override fun onDraw(c: Canvas) {
        drawScene(c, width.toFloat(), height.toFloat())
    }
}

// ======================================================================
// Glass panel: frosted backdrop + tint + gloss + specular rim
// ======================================================================

open class GlassPanel(ctx: Context, private val radiusDp: Float = 26f) : LinearLayout(ctx) {

    private val path = Path()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val gloss = Paint(Paint.ANTI_ALIAS_FLAG)
    private val frost = Paint().apply {
        isFilterBitmap = true
        val sat = ColorMatrix().apply { setSaturation(1.45f) }
        val lift = ColorMatrix(
            floatArrayOf(
                1.10f, 0f, 0f, 0f, 16f,
                0f, 1.10f, 0f, 0f, 16f,
                0f, 0f, 1.10f, 0f, 16f,
                0f, 0f, 0f, 1f, 0f
            )
        )
        sat.postConcat(lift)
        colorFilter = ColorMatrixColorFilter(sat)
    }
    private val loc1 = IntArray(2)
    private val loc2 = IntArray(2)
    private val dst = RectF()
    private val radius: Float = radiusDp * resources.displayMetrics.density

    init {
        orientation = VERTICAL
        setWillNotDraw(false)
        clipChildren = false
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        LiquidBackdrop.glass.add(this)
    }

    override fun onDetachedFromWindow() {
        LiquidBackdrop.glass.remove(this)
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val wf = w.toFloat()
        val hf = h.toFloat()
        path.reset()
        path.addRoundRect(0f, 0f, wf, hf, radius, radius, Path.Direction.CW)
        fill.shader = LinearGradient(
            0f, 0f, 0f, hf,
            intArrayOf(withAlpha(Color.WHITE, 46), withAlpha(Color.WHITE, 16)),
            null, Shader.TileMode.CLAMP
        )
        gloss.shader = LinearGradient(
            0f, 0f, 0f, min(hf, radius * 3.4f),
            intArrayOf(withAlpha(Color.WHITE, 70), withAlpha(Color.WHITE, 0)),
            null, Shader.TileMode.CLAMP
        )
        rim.shader = LinearGradient(
            0f, 0f, wf, hf,
            intArrayOf(withAlpha(Color.WHITE, 235), withAlpha(Color.WHITE, 40), withAlpha(Color.WHITE, 36), withAlpha(Color.WHITE, 150)),
            floatArrayOf(0f, 0.35f, 0.7f, 1f), Shader.TileMode.CLAMP
        )
        rim.strokeWidth = resources.displayMetrics.density * 1.2f
    }

    override fun onDraw(c: Canvas) {
        val bd = LiquidBackdrop.instance
        val bb = bd?.blur
        if (bd != null && bb != null) {
            getLocationInWindow(loc1)
            bd.getLocationInWindow(loc2)
            val ox = (loc1[0] - loc2[0]).toFloat()
            val oy = (loc1[1] - loc2[1]).toFloat()
            c.save()
            c.clipPath(path)
            dst.set(-ox, -oy, -ox + bd.width, -oy + bd.height)
            c.drawBitmap(bb, null, dst, frost)
            c.restore()
        }
        c.drawPath(path, fill)
        c.save()
        c.clipPath(path)
        c.drawRect(0f, 0f, width.toFloat(), min(height.toFloat(), radius * 3.4f), gloss)
        c.restore()
        c.drawPath(path, rim)
        super.onDraw(c)
    }
}

// ======================================================================
// Selectable row (title + optional description)
// ======================================================================

class GlassOption(ctx: Context, title: String, desc: String?, private val accent: Int = Pal.violet) :
    LinearLayout(ctx) {

    private var sel = 0f
    private var selected = false
    private var anim: ValueAnimator? = null
    private val d = resources.displayMetrics.density
    private val path = Path()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = d * 1.1f }
    private val mark = Paint(Paint.ANTI_ALIAS_FLAG)
    private val basePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = withAlpha(Color.WHITE, 22) }
    private val tick = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeWidth = d * 2f
    }

    init {
        orientation = VERTICAL
        setWillNotDraw(false)
        setPadding((16 * d).toInt(), (11 * d).toInt(), (44 * d).toInt(), (11 * d).toInt())
        layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = (8 * d).toInt()
        }
        addView(TextView(ctx).apply {
            text = title
            textSize = 15f
            setTextColor(Color.WHITE)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        })
        if (desc != null) {
            addView(TextView(ctx).apply {
                text = desc
                textSize = 12f
                setTextColor(withAlpha(Color.WHITE, 175))
                setPadding(0, (2 * d).toInt(), 0, 0)
            })
        }
        isClickable = true
        jellyPress()
    }

    fun setSelectedGlass(on: Boolean, animate: Boolean) {
        if (on == selected && animate) return
        selected = on
        anim?.cancel()
        val to = if (on) 1f else 0f
        if (!animate) {
            sel = to
            invalidate()
            return
        }
        anim = ValueAnimator.ofFloat(sel, to).apply {
            duration = 420
            interpolator = OvershootInterpolator(2.2f)
            addUpdateListener {
                sel = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val r = 16 * d
        path.reset()
        path.addRoundRect(0f, 0f, w.toFloat(), h.toFloat(), r, r, Path.Direction.CW)
    }

    override fun onDraw(c: Canvas) {
        val s = sel.coerceIn(0f, 1.2f)
        val h = height.toFloat()
        fill.shader = LinearGradient(
            0f, 0f, width.toFloat(), h,
            intArrayOf(
                withAlpha(accent, (170 * s).toInt() + 0), withAlpha(Pal.cyan, (80 * s).toInt())
            ),
            null, Shader.TileMode.CLAMP
        )
        // base glass
        fill.alpha = 255
        c.drawPath(path, basePaint)
        if (s > 0.01f) c.drawPath(path, fill)
        rim.color = withAlpha(Color.WHITE, (55 + 150 * s.coerceAtMost(1f)).toInt())
        c.drawPath(path, rim)
        // check mark
        if (s > 0.02f) {
            val cx = width - 22 * d
            val cy = h / 2f
            val r = 10 * d * s
            mark.color = withAlpha(Color.WHITE, (235 * s.coerceAtMost(1f)).toInt())
            c.drawCircle(cx, cy, r, mark)
            tick.color = withAlpha(accent, 255)
            val k = r / 10f
            c.drawLine(cx - 4.5f * k, cy + 0.5f * k, cx - 1.2f * k, cy + 3.6f * k, tick)
            c.drawLine(cx - 1.2f * k, cy + 3.6f * k, cx + 4.8f * k, cy - 3.4f * k, tick)
        }
        super.onDraw(c)
    }
}

// ======================================================================
// Compact chip (used inside FlowLayout) with optional color dot
// ======================================================================

class GlassChip(ctx: Context, label: String, private val dot: Int = 0, private val accent: Int = Pal.violet) :
    TextView(ctx) {

    private var sel = 0f
    private var selected = false
    private var anim: ValueAnimator? = null
    private val d = resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = d * 1.1f }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    init {
        text = label
        textSize = 13.5f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER_VERTICAL
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        val left = if (dot != 0) 34 else 16
        setPadding((left * d).toInt(), (9 * d).toInt(), (16 * d).toInt(), (9 * d).toInt())
        isClickable = true
        jellyPress()
    }

    fun setSelectedGlass(on: Boolean, animate: Boolean) {
        if (on == selected && animate) return
        selected = on
        anim?.cancel()
        val to = if (on) 1f else 0f
        if (!animate) {
            sel = to
            invalidate()
            return
        }
        anim = ValueAnimator.ofFloat(sel, to).apply {
            duration = 380
            interpolator = OvershootInterpolator(2.4f)
            addUpdateListener {
                sel = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onDraw(c: Canvas) {
        val s = sel.coerceIn(0f, 1.2f)
        val w = width.toFloat()
        val h = height.toFloat()
        rect.set(0f, 0f, w, h)
        fill.shader = null
        fill.color = withAlpha(Color.WHITE, 24)
        c.drawRoundRect(rect, h / 2f, h / 2f, fill)
        if (s > 0.01f) {
            fill.shader = LinearGradient(
                0f, 0f, w, h, withAlpha(accent, (200 * s.coerceAtMost(1f)).toInt()),
                withAlpha(Pal.cyan, (120 * s.coerceAtMost(1f)).toInt()), Shader.TileMode.CLAMP
            )
            c.drawRoundRect(rect, h / 2f, h / 2f, fill)
        }
        rim.color = withAlpha(Color.WHITE, (60 + 150 * s.coerceAtMost(1f)).toInt())
        rect.inset(rim.strokeWidth / 2f, rim.strokeWidth / 2f)
        c.drawRoundRect(rect, h / 2f, h / 2f, rim)
        if (dot != 0) {
            dotPaint.color = dot
            c.drawCircle(18 * d, h / 2f, 7 * d, dotPaint)
            rim.color = withAlpha(Color.WHITE, 140)
            c.drawCircle(18 * d, h / 2f, 7 * d, rim)
        }
        super.onDraw(c)
    }
}

/** Simple wrapping layout for chips. */
class FlowLayout(ctx: Context, private val gapPx: Int) : ViewGroup(ctx) {

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val maxW = MeasureSpec.getSize(wSpec) - paddingLeft - paddingRight
        var x = 0
        var y = 0
        var rowH = 0
        for (i in 0 until childCount) {
            val v = getChildAt(i)
            if (v.visibility == GONE) continue
            v.measure(
                MeasureSpec.makeMeasureSpec(maxW, MeasureSpec.AT_MOST),
                MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED)
            )
            if (x > 0 && x + v.measuredWidth > maxW) {
                x = 0
                y += rowH + gapPx
                rowH = 0
            }
            x += v.measuredWidth + gapPx
            rowH = max(rowH, v.measuredHeight)
        }
        setMeasuredDimension(
            MeasureSpec.getSize(wSpec),
            y + rowH + paddingTop + paddingBottom
        )
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val maxW = r - l - paddingLeft - paddingRight
        var x = 0
        var y = 0
        var rowH = 0
        for (i in 0 until childCount) {
            val v = getChildAt(i)
            if (v.visibility == GONE) continue
            if (x > 0 && x + v.measuredWidth > maxW) {
                x = 0
                y += rowH + gapPx
                rowH = 0
            }
            v.layout(
                paddingLeft + x, paddingTop + y,
                paddingLeft + x + v.measuredWidth, paddingTop + y + v.measuredHeight
            )
            x += v.measuredWidth + gapPx
            rowH = max(rowH, v.measuredHeight)
        }
    }
}

// ======================================================================
// Glass button
// ======================================================================

class GlassButton(ctx: Context, label: String, private val primary: Boolean = false) : TextView(ctx) {

    private val d = resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val gloss = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = d * 1.2f }
    private val rect = RectF()
    private var shine = 0f
    private val shineAnim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2600
        repeatCount = ValueAnimator.INFINITE
        addUpdateListener {
            shine = it.animatedValue as Float
            if (primary) invalidate()
        }
    }
    private val shinePaint = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        text = label
        textSize = 15f
        isAllCaps = false
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        setPadding((18 * d).toInt(), (13 * d).toInt(), (18 * d).toInt(), (13 * d).toInt())
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = (6 * d).toInt() }
        isClickable = true
        jellyPress()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (primary) shineAnim.start()
    }

    override fun onDetachedFromWindow() {
        shineAnim.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = h / 2.2f
        rect.set(0f, 0f, w, h)
        if (primary) {
            fill.shader = LinearGradient(
                0f, 0f, w, h, withAlpha(Pal.violet, 235), withAlpha(Pal.cyan, 220), Shader.TileMode.CLAMP
            )
        } else {
            fill.shader = null
            fill.color = withAlpha(Color.WHITE, 30)
        }
        c.drawRoundRect(rect, r, r, fill)
        gloss.shader = LinearGradient(
            0f, 0f, 0f, h * 0.55f, withAlpha(Color.WHITE, if (primary) 90 else 55), withAlpha(Color.WHITE, 0),
            Shader.TileMode.CLAMP
        )
        c.save()
        c.clipRect(0f, 0f, w, h * 0.55f)
        c.drawRoundRect(rect, r, r, gloss)
        c.restore()
        if (primary) {
            // moving specular streak
            val sw = w * 0.35f
            val x = -sw + shine * (w + sw * 2f)
            shinePaint.shader = LinearGradient(
                x, 0f, x + sw, 0f,
                intArrayOf(withAlpha(Color.WHITE, 0), withAlpha(Color.WHITE, 90), withAlpha(Color.WHITE, 0)),
                null, Shader.TileMode.CLAMP
            )
            val clip = Path().apply { addRoundRect(rect, r, r, Path.Direction.CW) }
            c.save()
            c.clipPath(clip)
            c.drawRect(0f, 0f, w, h, shinePaint)
            c.restore()
        }
        rim.shader = LinearGradient(
            0f, 0f, w, h,
            intArrayOf(withAlpha(Color.WHITE, 220), withAlpha(Color.WHITE, 40), withAlpha(Color.WHITE, 120)),
            null, Shader.TileMode.CLAMP
        )
        rect.inset(rim.strokeWidth / 2f, rim.strokeWidth / 2f)
        c.drawRoundRect(rect, r, r, rim)
        super.onDraw(c)
    }
}

// ======================================================================
// Title text with a moving shine
// ======================================================================

class ShimmerText(ctx: Context) : TextView(ctx) {
    private val m = Matrix()
    private var shader: LinearGradient? = null
    private var phase = 0f
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 3200
        repeatCount = ValueAnimator.INFINITE
        addUpdateListener {
            phase = it.animatedValue as Float
            invalidate()
        }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val sw = max(1f, w.toFloat())
        val sh = LinearGradient(
            0f, 0f, sw * 0.6f, 0f,
            intArrayOf(Color.WHITE, Color.rgb(170, 225, 255), Color.rgb(215, 190, 255), Color.WHITE),
            floatArrayOf(0f, 0.4f, 0.7f, 1f), Shader.TileMode.MIRROR
        )
        shader = sh
        paint.shader = sh
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        anim.start()
    }

    override fun onDetachedFromWindow() {
        anim.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        val sh = shader
        if (sh != null) {
            m.setTranslate(phase * width * 1.2f, 0f)
            sh.setLocalMatrix(m)
        }
        super.onDraw(c)
    }
}

/** Animated equalizer logo. */
class EqView(ctx: Context, private val colA: Int, private val colB: Int) : View(ctx) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private var t = 0f
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1600L
        repeatCount = ValueAnimator.INFINITE
        interpolator = android.view.animation.LinearInterpolator()
        addUpdateListener {
            t = it.animatedValue as Float
            invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        anim.start()
    }

    override fun onDetachedFromWindow() {
        anim.cancel()
        super.onDetachedFromWindow()
    }

    private fun lerp(a: Int, b: Int, f: Float): Int = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * f).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * f).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * f).toInt()
    )

    override fun onDraw(c: Canvas) {
        val n = 5
        val w = width.toFloat()
        val h = height.toFloat()
        val step = w / n
        paint.strokeWidth = step * 0.55f
        val pad = paint.strokeWidth / 2f
        for (i in 0 until n) {
            // integer frequencies 1..3 so the loop is seamless
            val ph = t * 6.2832f * (1 + i % 3) + i * 1.3f
            val v = 0.3f + 0.7f * (0.5f + 0.5f * sin(ph))
            val half = (h / 2f - pad) * v
            paint.color = lerp(colA, colB, i / (n - 1f))
            val x = step * (i + 0.5f)
            c.drawLine(x, h / 2f - half, x, h / 2f + half, paint)
        }
    }
}

