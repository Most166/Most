package com.musicwall.app

import android.Manifest
import android.app.Activity
import android.app.WallpaperManager
import android.content.res.ColorStateList
import android.content.ComponentName
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.io.File

/** Settings screen with a liquid-glass look. */
class MainActivity : Activity() {

    private companion object {
        const val REQ_BG = 42
        const val REQ_VIDEO_SONG = 43
        const val REQ_VIDEO_DEFAULT = 44
    }

    private lateinit var prefs: SharedPreferences
    private lateinit var content: LinearLayout
    private lateinit var backdrop: LiquidBackdrop

    private lateinit var statusNotif: TextView
    private lateinit var statusMic: TextView
    private lateinit var npArt: ImageView
    private lateinit var npTitle: TextView
    private lateinit var npArtist: TextView
    private lateinit var npState: TextView
    private lateinit var videoLinkBtn: GlassButton
    private lateinit var videoDefaultInfo: TextView
    private lateinit var videoDefaultRemove: GlassButton
    private lateinit var videoList: LinearLayout
    private lateinit var textSwitch: Switch
    private lateinit var videoSwitch: Switch
    private lateinit var idleSwitch: Switch

    private val styleRows = ArrayList<GlassOption>()
    private val autoChips = ArrayList<GlassChip>()
    private val colorChips = ArrayList<GlassChip>()
    private val bgChips = ArrayList<GlassChip>()
    private val sliderRefreshers = ArrayList<() -> Unit>()

    private val ui = Handler(Looper.getMainLooper())
    private var seenArtVersion = -1
    private var seenTrackVersion = -1
    private var uiReady = false

    private val poll = object : Runnable {
        override fun run() {
            refreshNowPlaying()
            ui.postDelayed(this, 500L)
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs.sp(this)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        buildUi()
        if (savedInstanceState == null) {
            // hide everything and start the entrance as soon as the first layout pass is done
            for (i in 0 until content.childCount) content.getChildAt(i).alpha = 0f
            content.viewTreeObserver.addOnGlobalLayoutListener(object : android.view.ViewTreeObserver.OnGlobalLayoutListener {
                override fun onGlobalLayout() {
                    content.viewTreeObserver.removeOnGlobalLayoutListener(this)
                    playEntrance()
                }
            })
        }
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
        refreshVideoUi()
        ui.post(poll)
    }

    override fun onPause() {
        ui.removeCallbacks(poll)
        super.onPause()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refreshStatus()
    }

    // ---------------- UI ----------------

    private fun buildUi() {
        val rootFrame = object : FrameLayout(this) {
            override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
                if (::backdrop.isInitialized) backdrop.touch(ev)
                return super.dispatchTouchEvent(ev)
            }
        }
        backdrop = LiquidBackdrop(this)
        rootFrame.addView(backdrop, FrameLayout.LayoutParams(-1, -1))

        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(52), dp(18), dp(36))
        }
        val scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(content)
        }
        rootFrame.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        rootFrame.setOnApplyWindowInsetsListener { _, ins ->
            @Suppress("DEPRECATION")
            content.setPadding(
                dp(18), ins.systemWindowInsetTop + dp(18), dp(18), ins.systemWindowInsetBottom + dp(32)
            )
            ins
        }

        buildHeader()
        buildNowPlaying()
        buildStyleCard()
        buildVideoCard()
        buildCustomizeCard()
        buildSetupCard()
        content.addView(
            text("Music Live Wallpaper 2.0", 12f, Color.argb(120, 255, 255, 255)).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(4), 0, 0)
            }
        )

        setContentView(rootFrame)
        rootFrame.requestApplyInsets()
        uiReady = true
        refreshUi(false)
    }

    private fun buildHeader() {
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), 0, 0, dp(4))
        }
        header.addView(
            EqView(this, Pal.violet, Pal.cyan).apply {
                layoutParams = LinearLayout.LayoutParams(dp(42), dp(42)).apply { rightMargin = dp(14) }
            }
        )
        header.addView(ShimmerText(this).apply {
            text = "Music Live Wallpaper"
            textSize = 27f
            setTextColor(Color.WHITE)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        })
        content.addView(header)
        content.addView(
            text("Liquid-glass visuals that dance to the song you are playing", 14f, Color.argb(190, 255, 255, 255))
                .also { it.setPadding(dp(4), dp(2), dp(4), dp(18)) }
        )
    }

    private fun buildNowPlaying() {
        val card = card()
        card.addView(label("Now playing"))
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, dp(10))
        }
        npArt = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply {
                setColor(Color.argb(50, 255, 255, 255))
                cornerRadius = dp(16).toFloat()
            }
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, dp(16).toFloat())
                }
            }
            clipToOutline = true
            layoutParams = LinearLayout.LayoutParams(dp(66), dp(66)).apply { rightMargin = dp(14) }
        }
        row.addView(npArt)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        npTitle = text("Nothing playing", 17f, Color.WHITE, bold = true).apply {
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        npArtist = text("", 13f, Color.argb(190, 255, 255, 255)).apply {
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        npState = text("", 12f, Pal.cyan)
        col.addView(npTitle)
        col.addView(npArtist)
        col.addView(npState)
        row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        card.addView(row)
        card.addView(GlassButton(this, "Set as live wallpaper", primary = true).apply {
            setOnClickListener { setWallpaper() }
        })
        content.addView(card)
    }

    private fun buildStyleCard() {
        val card = card()
        card.addView(label("Wallpaper style"))
        card.addView(
            text("Tap to switch. The wallpaper changes instantly.", 12f, Color.argb(170, 255, 255, 255))
                .also { it.setPadding(0, dp(4), 0, dp(12)) }
        )
        for (i in 0 until Styles.COUNT) {
            val row = GlassOption(this, Styles.names[i], Styles.descs[i]).apply {
                setOnClickListener {
                    Prefs.setStyle(prefs, i)
                    refreshUi(true)
                }
            }
            styleRows.add(row)
            card.addView(row)
        }
        card.addView(sectionLabel("Auto-switch style"))
        card.addView(chips(AutoMode.names.toList(), null, autoChips) { i ->
            Prefs.setAuto(prefs, i)
            refreshUi(true)
        })
        content.addView(card)
    }

    private fun buildVideoCard() {
        val card = card()
        card.addView(label("Video wallpaper"))
        card.addView(
            text(
                "Some songs are videos? Link a video to a song and it plays behind the effects whenever " +
                    "that song plays. Videos are muted - your music app keeps the sound.",
                12f, Color.argb(175, 255, 255, 255)
            ).also { it.setPadding(0, dp(4), 0, dp(6)) }
        )
        videoSwitch = switchRow("Play videos on the wallpaper") { checked ->
            prefs.edit().putBoolean(Prefs.VIDEO_ON, checked).apply()
        }
        card.addView(videoSwitch)

        videoLinkBtn = GlassButton(this, "Link a video to the current song", primary = true).apply {
            setOnClickListener { linkVideoToCurrent() }
        }
        card.addView(videoLinkBtn)

        card.addView(sectionLabel("Default video"))
        videoDefaultInfo = text("", 13f, Color.argb(200, 255, 255, 255)).also { it.setPadding(0, 0, 0, dp(4)) }
        card.addView(videoDefaultInfo)
        card.addView(GlassButton(this, "Choose default video (songs without their own)").apply {
            setOnClickListener { pickVideo(REQ_VIDEO_DEFAULT) }
        })
        videoDefaultRemove = GlassButton(this, "Remove default video").apply {
            setOnClickListener {
                VideoLibrary.defaultUri(prefs)?.let { releaseUri(it) }
                prefs.edit().remove(Prefs.VIDEO_DEFAULT).apply()
                refreshVideoUi()
            }
        }
        card.addView(videoDefaultRemove)

        card.addView(sectionLabel("Linked songs"))
        videoList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        card.addView(videoList)

        card.addView(slider("Video dimming", Prefs.VIDEO_DIM, 0, 80, 25))
        idleSwitch = switchRow("Keep video running while music is paused") { checked ->
            prefs.edit().putBoolean(Prefs.VIDEO_IDLE, checked).apply()
        }
        card.addView(idleSwitch)
        content.addView(card)
    }

    private fun buildCustomizeCard() {
        val card = card()
        card.addView(label("Customize"))

        card.addView(sectionLabel("Colors"))
        val names = Themes.names()
        val dots = listOf(0) + Themes.list.map { it.accent }
        card.addView(chips(names, dots, colorChips) { i ->
            Prefs.setInt(prefs, Prefs.COLOR, i)
            refreshUi(true)
        })

        card.addView(sectionLabel("Background"))
        card.addView(chips(BgMode.names, null, bgChips) { i ->
            if (i == BgMode.IMAGE && !File(filesDir, Prefs.BG_FILE).exists()) {
                pickImage()
            } else {
                Prefs.setInt(prefs, Prefs.BG, i)
                refreshUi(true)
            }
        })
        card.addView(GlassButton(this, "Choose / change gallery image").apply { setOnClickListener { pickImage() } })
        card.addView(slider("Gallery image dimming", Prefs.BGDIM, 0, 85, 35))

        card.addView(sectionLabel("Effects"))
        card.addView(slider("Effect intensity", Prefs.INTENSITY, 50, 150, 100))
        card.addView(slider("Beat FX (flash, shake, sparks, shockwaves)", Prefs.FX, 0, 200, 100))
        card.addView(slider("Cover / element size", Prefs.COVER, 70, 130, 100))
        card.addView(slider("Particle count", Prefs.PARTS, 0, 100, 100))
        card.addView(slider("Spin speed", Prefs.ROT, 0, 200, 100))
        textSwitch = switchRow("Show song title and artist") { checked ->
            prefs.edit().putBoolean(Prefs.TEXT, checked).apply()
        }
        card.addView(textSwitch)
        card.addView(GlassButton(this, "Reset all customization").apply {
            setOnClickListener {
                Prefs.resetCustom(prefs)
                refreshUi(true)
            }
        })
        content.addView(card)
    }

    private fun buildSetupCard() {
        val card = card()
        card.addView(label("Setup"))

        card.addView(sectionLabel("1) Notification access (required)"))
        statusNotif = text("", 14f, Color.WHITE).also { it.setPadding(0, 0, 0, dp(6)) }
        card.addView(statusNotif)
        card.addView(GlassButton(this, "Open notification access settings").apply {
            setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        })
        card.addView(
            text(
                "If the switch is greyed out (app installed outside the Play Store): open App info, tap the " +
                    "three dots at the top right, choose \"Allow restricted settings\", then enable the switch again.",
                12f, Color.argb(170, 255, 255, 255)
            ).also { it.setPadding(0, dp(8), 0, dp(4)) }
        )
        card.addView(GlassButton(this, "Open app info").apply {
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            }
        })

        card.addView(sectionLabel("2) Microphone (optional)"))
        card.addView(
            text(
                "Android requires this permission for the Visualizer API, which reads the spectrum of the audio " +
                    "that is playing. The app never records audio or sends anything anywhere. Without it the " +
                    "effects move to a simulated beat.",
                12f, Color.argb(170, 255, 255, 255)
            )
        )
        statusMic = text("", 14f, Color.WHITE).also { it.setPadding(0, dp(8), 0, dp(6)) }
        card.addView(statusMic)
        card.addView(GlassButton(this, "Allow microphone").apply {
            setOnClickListener { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1) }
        })
        content.addView(card)
    }

    /** Entrance animation: cards fly in one after another with a jelly overshoot. */
    private fun playEntrance() {
        val dist = dp(90).toFloat()
        for (i in 0 until content.childCount) {
            val v = content.getChildAt(i)
            v.alpha = 0f
            v.translationY = dist
            v.scaleX = 0.9f
            v.scaleY = 0.9f
            v.rotation = if (i % 2 == 0) -2.5f else 2.5f
            v.pivotX = v.width / 2f
            v.pivotY = v.height / 2f
            v.animate()
                .alpha(1f).translationY(0f).scaleX(1f).scaleY(1f).rotation(0f)
                .setStartDelay(80L + i * 90L)
                .setDuration(750L)
                .setInterpolator(OvershootInterpolator(1.25f))
                .start()
        }
    }

    // ---------------- building blocks ----------------

    private fun text(s: String, sp: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = s
            textSize = sp
            setTextColor(color)
            if (bold) typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

    private fun label(s: String): TextView = text(s, 17f, Color.WHITE, bold = true)

    private fun sectionLabel(s: String): TextView =
        text(s, 14f, Color.WHITE, bold = true).also { it.setPadding(0, dp(16), 0, dp(8)) }

    private fun card(): GlassPanel = GlassPanel(this).apply {
        setPadding(dp(18), dp(18), dp(18), dp(18))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(16) }
    }

    private fun chips(
        items: List<String>,
        dots: List<Int>?,
        registry: ArrayList<GlassChip>,
        onPick: (Int) -> Unit
    ): FlowLayout {
        val flow = FlowLayout(this, dp(8))
        items.forEachIndexed { i, name ->
            val chip = GlassChip(this, name, dots?.get(i) ?: 0).apply { setOnClickListener { onPick(i) } }
            registry.add(chip)
            flow.addView(chip)
        }
        return flow
    }

    private fun switchRow(label: String, onChange: (Boolean) -> Unit): Switch =
        Switch(this).apply {
            text = label
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(0, dp(10), 0, dp(10))
            thumbTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(Color.WHITE, Color.argb(210, 235, 235, 245))
            )
            trackTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(Color.argb(220, 124, 92, 255), Color.argb(90, 255, 255, 255))
            )
            setOnCheckedChangeListener { _, checked -> if (uiReady) onChange(checked) }
        }

    /** Slider (lo..hi) that saves to prefs immediately. */
    private fun slider(label: String, key: String, lo: Int, hi: Int, def: Int): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(10), 0, dp(2))
        }
        val tv = text("", 13f, Color.WHITE)
        val bar = SeekBar(this)
        bar.max = hi - lo
        bar.progressTintList = ColorStateList.valueOf(Pal.cyan)
        bar.progressBackgroundTintList = ColorStateList.valueOf(Color.argb(90, 255, 255, 255))
        bar.thumbTintList = ColorStateList.valueOf(Color.WHITE)
        val refresh = {
            val v = Prefs.getInt(prefs, key, def).coerceIn(lo, hi)
            bar.progress = v - lo
            tv.text = "$label: $v%"
        }
        refresh()
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val v = progress + lo
                tv.text = "$label: $v%"
                if (fromUser) Prefs.setInt(prefs, key, v)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        sliderRefreshers.add(refresh)
        box.addView(tv)
        box.addView(bar)
        return box
    }

    // ---------------- state refresh ----------------

    private fun refreshUi(animate: Boolean) {
        val cur = Prefs.style(prefs)
        for (i in styleRows.indices) styleRows[i].setSelectedGlass(i == cur, animate)
        val auto = Prefs.auto(prefs)
        for (i in autoChips.indices) autoChips[i].setSelectedGlass(i == auto, animate)
        val color = Prefs.getInt(prefs, Prefs.COLOR, 0)
        for (i in colorChips.indices) colorChips[i].setSelectedGlass(i == color, animate)
        val bg = Prefs.getInt(prefs, Prefs.BG, BgMode.DEFAULT)
        for (i in bgChips.indices) bgChips[i].setSelectedGlass(i == bg, animate)
        for (r in sliderRefreshers) r()
        val was = uiReady
        uiReady = false
        textSwitch.isChecked = prefs.getBoolean(Prefs.TEXT, true)
        videoSwitch.isChecked = prefs.getBoolean(Prefs.VIDEO_ON, false)
        idleSwitch.isChecked = prefs.getBoolean(Prefs.VIDEO_IDLE, false)
        uiReady = was
    }

    private fun refreshNowPlaying() {
        val title = MusicState.title
        val artist = MusicState.artist
        if (MusicState.version != seenArtVersion) {
            seenArtVersion = MusicState.version
            val a = MusicState.art
            if (a != null) npArt.setImageBitmap(a) else npArt.setImageDrawable(null)
        }
        if (MusicState.trackVersion != seenTrackVersion) {
            seenTrackVersion = MusicState.trackVersion
            npTitle.animate().alpha(0f).setDuration(120).withEndAction {
                npTitle.text = if (title.isEmpty()) "Nothing playing" else title
                npTitle.animate().alpha(1f).setDuration(220).start()
            }.start()
            npArtist.text = artist
        }
        npState.text = when {
            !MusicState.listenerConnected -> "Enable notification access below"
            MusicState.playing -> "Playing"
            title.isNotEmpty() -> "Paused"
            else -> "Start a song in any music app"
        }
        videoLinkBtn.alpha = if (title.isEmpty()) 0.5f else 1f
    }

    private fun refreshVideoUi() {
        val def = VideoLibrary.defaultUri(prefs)
        videoDefaultInfo.text = if (def != null) "Default video is set" else "No default video"
        videoDefaultRemove.visibility = if (def != null) View.VISIBLE else View.GONE

        videoList.removeAllViews()
        val items = VideoLibrary.list(prefs)
        if (items.isEmpty()) {
            videoList.addView(text("No linked songs yet", 13f, Color.argb(170, 255, 255, 255)))
        }
        for (e in items) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(4), 0, dp(4))
            }
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            col.addView(text(e.title.ifEmpty { "(untitled)" }, 14f, Color.WHITE, bold = true).apply {
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
            })
            if (e.artist.isNotEmpty()) {
                col.addView(text(e.artist, 12f, Color.argb(170, 255, 255, 255)).apply {
                    maxLines = 1
                    ellipsize = android.text.TextUtils.TruncateAt.END
                })
            }
            row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(GlassChip(this, "Remove").apply {
                setOnClickListener {
                    releaseUri(e.uri)
                    VideoLibrary.remove(prefs, e.key)
                    refreshVideoUi()
                }
            })
            videoList.addView(row)
        }
    }

    private fun notificationAccessGranted(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        return enabled?.contains(packageName) == true
    }

    private fun micGranted(): Boolean =
        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun refreshStatus() {
        val okColor = Color.rgb(120, 230, 150)
        val noColor = Color.rgb(255, 140, 140)

        val n = notificationAccessGranted()
        statusNotif.text = if (n) "Enabled" else "Not enabled yet"
        statusNotif.setTextColor(if (n) okColor else noColor)

        val m = micGranted()
        statusMic.text = if (m) "Allowed (reading the real audio)" else "Not allowed (using a simulated beat)"
        statusMic.setTextColor(if (m) okColor else Color.argb(200, 255, 255, 255))
    }

    // ---------------- pickers ----------------

    private fun pickImage() {
        try {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "image/*"
            }
            startActivityForResult(i, REQ_BG)
        } catch (_: Exception) {
            Toast.makeText(this, "Could not open the gallery", Toast.LENGTH_SHORT).show()
        }
    }

    private fun pickVideo(req: Int) {
        try {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "video/*"
                addFlags(
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                )
            }
            startActivityForResult(i, req)
        } catch (_: Exception) {
            Toast.makeText(this, "Could not open the file picker", Toast.LENGTH_SHORT).show()
        }
    }

    private fun linkVideoToCurrent() {
        val title = MusicState.title
        if (title.isBlank()) {
            Toast.makeText(this, "Play a song first, then tap this button again", Toast.LENGTH_LONG).show()
            return
        }
        prefs.edit().putString(Prefs.PEND_TITLE, title).putString(Prefs.PEND_ARTIST, MusicState.artist).apply()
        pickVideo(REQ_VIDEO_SONG)
    }

    private fun releaseUri(uri: String) {
        try {
            contentResolver.releasePersistableUriPermission(Uri.parse(uri), Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Throwable) {
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        when (requestCode) {
            REQ_BG -> importBg(uri)
            REQ_VIDEO_SONG, REQ_VIDEO_DEFAULT -> {
                try {
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: Throwable) {
                }
                if (requestCode == REQ_VIDEO_SONG) {
                    val t = prefs.getString(Prefs.PEND_TITLE, "") ?: ""
                    val a = prefs.getString(Prefs.PEND_ARTIST, "") ?: ""
                    VideoLibrary.put(prefs, t, a, uri.toString())
                    Toast.makeText(this, "Video linked to \"$t\"", Toast.LENGTH_SHORT).show()
                } else {
                    prefs.edit().putString(Prefs.VIDEO_DEFAULT, uri.toString()).apply()
                    Toast.makeText(this, "Default video set", Toast.LENGTH_SHORT).show()
                }
                prefs.edit().putBoolean(Prefs.VIDEO_ON, true).apply()
                videoSwitch.isChecked = true
                refreshVideoUi()
            }
        }
    }

    /** Downsizes the image (long side <= ~2000px) and stores it inside the app, so no storage permission is needed. */
    private fun importBg(uri: Uri) {
        Thread {
            var ok = false
            try {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                var sample = 1
                while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 2000) sample *= 2
                val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                if (bmp != null) {
                    File(filesDir, Prefs.BG_FILE).outputStream().use { out ->
                        bmp.compress(Bitmap.CompressFormat.JPEG, 90, out)
                    }
                    bmp.recycle()
                    ok = true
                }
            } catch (_: Throwable) {
            }
            runOnUiThread {
                if (ok) {
                    Prefs.setInt(prefs, Prefs.BGVER, Prefs.getInt(prefs, Prefs.BGVER, 0) + 1)
                    Prefs.setInt(prefs, Prefs.BG, BgMode.IMAGE)
                    refreshUi(true)
                } else {
                    Toast.makeText(this, "Could not load the image", Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }

    private fun setWallpaper() {
        try {
            val i = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).putExtra(
                WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                ComponentName(this, MusicWallpaperService::class.java)
            )
            startActivity(i)
        } catch (_: Exception) {
            try {
                startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
            } catch (_: Exception) {
            }
        }
    }
}
