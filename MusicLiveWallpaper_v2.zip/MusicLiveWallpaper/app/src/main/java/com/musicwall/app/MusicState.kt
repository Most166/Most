package com.musicwall.app

import android.graphics.Bitmap

/** Now-playing state shared between MediaListenerService (writer) and the wallpaper / app UI (readers). */
object MusicState {
    @Volatile var art: Bitmap? = null
    @Volatile var title: String = ""
    @Volatile var artist: String = ""
    @Volatile var playing: Boolean = false
    @Volatile var listenerConnected: Boolean = false

    /** Incremented every time the album art changes, so the wallpaper knows to recompute colors. */
    @Volatile var version: Int = 0

    /** Incremented every time the track (title/artist) changes. Used to pick the matching video. */
    @Volatile var trackVersion: Int = 0

    @Synchronized
    fun bump() {
        version += 1
    }

    @Synchronized
    fun bumpTrack() {
        trackVersion += 1
    }
}
