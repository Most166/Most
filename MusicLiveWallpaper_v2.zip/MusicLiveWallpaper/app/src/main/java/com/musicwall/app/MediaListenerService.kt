package com.musicwall.app

import android.content.ComponentName
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.service.notification.NotificationListenerService
import kotlin.concurrent.thread

/**
 * Reads now-playing info from the MediaSession of any music app (Spotify, YouTube Music, ...).
 * Requires the "Notification access" permission for this app.
 */
class MediaListenerService : NotificationListenerService() {

    private var manager: MediaSessionManager? = null
    private var componentName: ComponentName? = null
    private var registered: List<MediaController> = emptyList()

    @Volatile
    private var lastKey: String = ""

    @Volatile
    private var lastTrack: String = ""

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { _ -> refresh() }

    private val callback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = refresh()
        override fun onPlaybackStateChanged(state: PlaybackState?) = refresh()
        override fun onSessionDestroyed() = refresh()
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        MusicState.listenerConnected = true
        val mgr = getSystemService(MediaSessionManager::class.java)
        val cn = ComponentName(this, MediaListenerService::class.java)
        manager = mgr
        componentName = cn
        try {
            mgr.addOnActiveSessionsChangedListener(sessionsListener, cn)
        } catch (_: SecurityException) {
        }
        refresh()
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        cleanup()
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    private fun cleanup() {
        MusicState.listenerConnected = false
        try {
            manager?.removeOnActiveSessionsChangedListener(sessionsListener)
        } catch (_: Exception) {
        }
        registered.forEach {
            try {
                it.unregisterCallback(callback)
            } catch (_: Exception) {
            }
        }
        registered = emptyList()
        MusicState.playing = false
    }

    private fun refresh() {
        val mgr = manager ?: return
        val cn = componentName ?: return
        val list: List<MediaController> = try {
            mgr.getActiveSessions(cn)
        } catch (_: SecurityException) {
            emptyList()
        }

        if (!sameSessions(list, registered)) {
            registered.forEach {
                try {
                    it.unregisterCallback(callback)
                } catch (_: Exception) {
                }
            }
            list.forEach {
                try {
                    it.registerCallback(callback)
                } catch (_: Exception) {
                }
            }
            registered = list
        }

        val chosen = list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: list.firstOrNull()

        if (chosen == null) {
            MusicState.playing = false
            return
        }
        apply(chosen)
    }

    private fun sameSessions(a: List<MediaController>, b: List<MediaController>): Boolean {
        if (a.size != b.size) return false
        for (i in a.indices) {
            if (a[i].sessionToken != b[i].sessionToken) return false
        }
        return true
    }

    private fun apply(controller: MediaController) {
        val meta = controller.metadata
        val title = meta?.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: meta?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
            ?: ""
        val artist = meta?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: meta?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: meta?.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE)
            ?: ""
        val bmp: Bitmap? = meta?.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: meta?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: meta?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        val uri = meta?.getString(MediaMetadata.METADATA_KEY_ART_URI)
            ?: meta?.getString(MediaMetadata.METADATA_KEY_ALBUM_ART_URI)
            ?: meta?.getString(MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI)

        MusicState.playing = controller.playbackState?.state == PlaybackState.STATE_PLAYING

        val key = "$title|$artist|${System.identityHashCode(bmp)}|${uri ?: ""}"
        if (key == lastKey) return
        lastKey = key

        MusicState.title = title
        MusicState.artist = artist
        val trackKey = "$title|$artist"
        if (trackKey != lastTrack) {
            lastTrack = trackKey
            MusicState.bumpTrack()
        }

        if (bmp != null) {
            MusicState.art = prepare(bmp)
            MusicState.bump()
        } else if (uri != null && (uri.startsWith("content://") || uri.startsWith("file://"))) {
            thread {
                try {
                    val decoded = contentResolver.openInputStream(Uri.parse(uri))?.use {
                        BitmapFactory.decodeStream(it)
                    }
                    if (decoded != null && lastKey == key) {
                        MusicState.art = prepare(decoded)
                        MusicState.bump()
                    }
                } catch (_: Exception) {
                }
            }
        } else {
            MusicState.art = null
            MusicState.bump()
        }
    }

    /** Converts to a plain (non-HARDWARE) bitmap and downsizes to at most 640px. */
    private fun prepare(src: Bitmap): Bitmap? {
        return try {
            val soft = if (src.config == Bitmap.Config.HARDWARE) {
                src.copy(Bitmap.Config.ARGB_8888, false) ?: return null
            } else {
                src
            }
            val m = maxOf(soft.width, soft.height)
            if (m > 640) {
                Bitmap.createScaledBitmap(soft, soft.width * 640 / m, soft.height * 640 / m, true)
            } else {
                soft
            }
        } catch (_: Throwable) {
            null
        }
    }
}
