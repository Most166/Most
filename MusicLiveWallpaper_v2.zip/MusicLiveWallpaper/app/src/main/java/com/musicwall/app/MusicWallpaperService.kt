package com.musicwall.app

import android.Manifest
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.media.audiofx.Visualizer
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.service.wallpaper.WallpaperService
import android.text.TextPaint
import android.text.TextUtils
import android.view.SurfaceHolder
import androidx.palette.graphics.Palette
import java.io.File
import java.util.Random
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

private const val BANDS = 36      // frequency bands (half circle)
private const val BARS = 72       // bars around the cover (mirrored left/right)
private const val PARTICLES = 40
private const val SPARKS = 90     // beat sparks pool
private const val STARS = 120     // hyperspace stars
private const val SHOCKS = 5      // simultaneous shockwave rings
private const val OVERLAY_MAX_SIDE = 720f // video mode: effects are drawn at this short-side resolution
private const val AUTO_INTERVAL_MS = 120_000L // auto mode: switch every 2 minutes
private const val FADE_MS = 450L              // fade-in when the style changes

private fun mix(a: Int, b: Int, f: Float): Int {
    val r = (Color.red(a) + (Color.red(b) - Color.red(a)) * f).toInt()
    val g = (Color.green(a) + (Color.green(b) - Color.green(a)) * f).toInt()
    val bl = (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * f).toInt()
    return Color.rgb(r, g, bl)
}

private fun chaseCh(a: Int, b: Int, k: Float): Int {
    val d = b - a
    return if (abs(d) <= 6) b else a + (d * k).roundToInt()
}

private fun chase(a: Int, b: Int, k: Float): Int = Color.rgb(
    chaseCh(Color.red(a), Color.red(b), k),
    chaseCh(Color.green(a), Color.green(b), k),
    chaseCh(Color.blue(a), Color.blue(b), k)
)

private fun vivid(c: Int): Int {
    val hsv = FloatArray(3)
    Color.colorToHSV(c, hsv)
    if (hsv[1] > 0.12f) hsv[1] = max(hsv[1], 0.5f)
    hsv[2] = max(hsv[2], 0.88f)
    return Color.HSVToColor(hsv)
}

private fun deep(c: Int): Int {
    val hsv = FloatArray(3)
    Color.colorToHSV(c, hsv)
    hsv[2] = min(max(hsv[2], 0.08f), 0.20f)
    return Color.HSVToColor(hsv)
}

private fun shiftHue(c: Int, deg: Float): Int {
    val hsv = FloatArray(3)
    Color.colorToHSV(c, hsv)
    hsv[0] = (hsv[0] + deg) % 360f
    return Color.HSVToColor(hsv)
}

private fun colorDist(a: Int, b: Int): Int =
    abs(Color.red(a) - Color.red(b)) + abs(Color.green(a) - Color.green(b)) + abs(Color.blue(a) - Color.blue(b))

class MusicWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = MusicEngine()

    inner class MusicEngine : Engine() {

        // ---------- default colors (when there is no album art) ----------
        private val defAccent = Color.rgb(124, 92, 255)
        private val defSoft = Color.rgb(64, 196, 255)
        private val defBg = Color.rgb(14, 12, 30)

        private var curAccent = defAccent
        private var curSoft = defSoft
        private var curBg = defBg
        private var tgtAccent = defAccent
        private var tgtSoft = defSoft
        private var tgtBg = defBg

        // ---------- system ----------
        private val handler = Handler(Looper.getMainLooper())
        private val startTime = SystemClock.uptimeMillis()
        private var lastNow = 0L
        private var visible = false
        private var surfW = 0
        private var surfH = 0

        private val frameRunnable = object : Runnable {
            override fun run() {
                if (!visible) return
                drawFrame()
                handler.postDelayed(this, if (MusicState.playing) 25L else 66L)
            }
        }

        // ---------- layout ----------
        private var u = 0f
        private var cx = 0f
        private var cy = 0f
        private var coverR = 0f
        private var maxBar = 0f
        private var glowR = 0f
        private val fullRect = Rect()
        private val cosT = FloatArray(BARS)
        private val sinT = FloatArray(BARS)

        // ---------- album art ----------
        private var seenVersion = -1
        private var art: Bitmap? = null
        private var tiny: Bitmap? = null
        private var coverBmp: Bitmap? = null
        private var coverDirty = true
        private var cardBmp: Bitmap? = null   // rounded-square cover
        private val squareSrc = Rect()        // centered square part of the cover
        private var cardSide = 0f
        private var blobR = 0f
        private val tmpRect = RectF()
        private val wavePath = Path()

        // ---------- wallpaper style ----------
        private val prefs: SharedPreferences = Prefs.sp(applicationContext)
        private var prefStyle = Styles.VINYL
        private var prefAuto = AutoMode.OFF
        private var activeStyle = Styles.VINYL
        private var fadeStart = -10_000L
        private var lastStyleSwitch = 0L
        private var artSeenOnce = false
        // the listener must be kept in a field (SharedPreferences holds it weakly)
        private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> applyPrefs() }

        // ---------- user settings ----------
        private var sIntensity = 1f
        private var sCover = 1f
        private var sParts = PARTICLES
        private var sRot = 1f
        private var sText = true
        private var sColorMode = 0
        private var sBgMode = BgMode.DEFAULT
        private var sBgDim = 0.35f
        private var customBg: Bitmap? = null
        private val customSrc = Rect()
        private var loadedBgVer = -1
        private var artAccent = defAccent
        private var artSoft = defSoft
        private var artBg = defBg
        private val customPaint = Paint().apply { isFilterBitmap = true }
        private val bgDimPaint = Paint()

        // ---------- audio / effects ----------
        private val bands = FloatArray(BANDS)
        private val target = FloatArray(BANDS)
        private val vizTarget = FloatArray(BANDS)
        @Volatile private var lastVizSignal = 0L
        private var viz: Visualizer? = null
        private var lastVizTry = 0L
        private var lastPlayingTs = 0L
        private var level = 0f
        private var bassAvg = 0f
        private var rotation = 0f
        private val ringBirths = ArrayList<Long>()
        private var lastRing = 0L

        // ---------- crazy FX ----------
        private var sFx = 1f
        private var punch = 0f          // zoom/shake impulse, decays after each beat
        private var flash = 0f          // screen flash impulse
        private var fxX = 0f            // focal point of shockwaves / sparks (set by each style)
        private var fxY = 0f
        private val shockBirth = LongArray(SHOCKS)
        private val shockX = FloatArray(SHOCKS)
        private val shockY = FloatArray(SHOCKS)
        private val shockStr = FloatArray(SHOCKS)
        private var shockNext = 0
        private val spX = FloatArray(SPARKS)
        private val spY = FloatArray(SPARKS)
        private val spVx = FloatArray(SPARKS)
        private val spVy = FloatArray(SPARKS)
        private val spLife = FloatArray(SPARKS)
        private val spMax = FloatArray(SPARKS)
        private val spCol = IntArray(SPARKS)
        private var spNext = 0
        private val peaks = FloatArray(BANDS)
        private val sparkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
        }
        private val flashPaint = Paint()
        private val sweepPaint = Paint()
        private var sweepShader: Shader? = null
        private val glassPath = Path()
        private val glassRect = RectF()
        private val glassRim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
        private val glassGloss = Paint(Paint.ANTI_ALIAS_FLAG)
        private val glassWash = Paint(Paint.ANTI_ALIAS_FLAG)
        private val frostPaint = Paint().apply { isFilterBitmap = true }
        private val stX = FloatArray(STARS)
        private val stY = FloatArray(STARS)
        private val stZ = FloatArray(STARS)
        private val orbitPath = Path()

        // ---------- video ----------
        private var videoGl: VideoGl? = null
        private var videoActive = false
        private var videoBrokenUri: String? = null
        private var desiredVideo: String? = null
        private var sVideoDim = 0.25f
        private var sVideoIdle = false
        private var seenTrack = -1
        private var surfaceReady = false
        private var ovW = 0
        private var ovH = 0
        private val ovScratch = Paint()

        private val rnd = Random(7)
        private val px = FloatArray(PARTICLES)
        private val py = FloatArray(PARTICLES)
        private val pr = FloatArray(PARTICLES)
        private val pv = FloatArray(PARTICLES)
        private val pph = FloatArray(PARTICLES)

        // ---------- Paint ----------
        private val bgPaint = Paint()
        private val tinyPaint = Paint().apply { isFilterBitmap = true; alpha = 70 }
        private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
        }
        private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
        private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = Color.argb(70, 255, 255, 255)
        }
        private val coverPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { isFilterBitmap = true }
        private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val dimPaint = Paint().apply { color = Color.argb(120, 0, 0, 0) }
        private val fadePaint = Paint()
        private val scrimPaint = Paint()
        private val posterFadePaint = Paint()
        private val particlePaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        private val artistPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(205, 255, 255, 255)
            textAlign = Paint.Align.CENTER
        }
        private val notePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(225, 255, 255, 255)
            textAlign = Paint.Align.CENTER
        }

        // ---------- Shaders (rebuilt only when colors / size change) ----------
        private var glowShader: Shader? = null
        private val blobShaders = arrayOfNulls<Shader>(3)
        private var builtAccent = 0
        private var builtBg = 0
        private var builtSoft = 0
        private var shadersDirty = true

        // ---------- text ----------
        private var shownTitle: String? = null
        private var shownArtist: String? = null
        private var shownConn = false
        private var textDirty = true
        private var line1 = ""
        private var line2 = ""

        // ---------- Visualizer (real audio spectrum) ----------
        private val fftListener = object : Visualizer.OnDataCaptureListener {
            override fun onWaveFormDataCapture(v: Visualizer?, waveform: ByteArray?, samplingRate: Int) {}

            override fun onFftDataCapture(v: Visualizer?, fft: ByteArray?, samplingRate: Int) {
                if (fft == null) return
                val bins = fft.size / 2
                val top = min(bins - 1, 190).toFloat()
                if (top < 2f) return
                var any = false
                for (b in 0 until BANDS) {
                    val lo = top.pow(b / BANDS.toFloat()).toInt().coerceAtLeast(1)
                    var hi = top.pow((b + 1) / BANDS.toFloat()).toInt()
                    if (hi <= lo) hi = lo + 1
                    var mx = 0f
                    for (i in lo until min(hi, bins)) {
                        val re = fft[2 * i].toInt()
                        val im = fft[2 * i + 1].toInt()
                        val m = sqrt((re * re + im * im).toFloat())
                        if (m > mx) mx = m
                    }
                    val tilt = 1f + 1.2f * b / BANDS
                    val value = ((mx * tilt) / 70f).coerceIn(0f, 1f).pow(0.85f)
                    vizTarget[b] = value
                    if (value > 0.05f) any = true
                }
                if (any) lastVizSignal = SystemClock.uptimeMillis()
            }
        }

        init {
            prefs.registerOnSharedPreferenceChangeListener(prefsListener)
            prefStyle = Prefs.style(prefs)
            prefAuto = Prefs.auto(prefs)
            activeStyle = prefStyle
            lastStyleSwitch = SystemClock.uptimeMillis()
            applyPrefs()
            for (i in 0 until BARS) {
                val a = (-PI / 2 + (i + 0.5) * (2 * PI / BARS)).toFloat()
                cosT[i] = cos(a)
                sinT[i] = sin(a)
            }
        }

        // ================= Engine callbacks =================

        override fun onSurfaceCreated(holder: SurfaceHolder?) {
            super.onSurfaceCreated(holder)
            surfaceReady = true
        }

        override fun onSurfaceChanged(holder: SurfaceHolder?, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            surfW = width
            surfH = height
            layout()
            videoGl?.resize(width, height)
            if (visible) drawFrame()
        }

        override fun onVisibilityChanged(visible: Boolean) {
            this.visible = visible
            handler.removeCallbacks(frameRunnable)
            if (visible) {
                lastNow = 0L
                handler.post(frameRunnable)
            } else {
                stopVideo()
                releaseViz()
            }
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder?) {
            super.onSurfaceDestroyed(holder)
            visible = false
            surfaceReady = false
            handler.removeCallbacks(frameRunnable)
            stopVideo()
            releaseViz()
        }

        override fun onDestroy() {
            prefs.unregisterOnSharedPreferenceChangeListener(prefsListener)
            visible = false
            handler.removeCallbacks(frameRunnable)
            stopVideo()
            releaseViz()
            super.onDestroy()
        }

        // ================= layout =================

        private fun layout() {
            if (surfW <= 0 || surfH <= 0) return
            u = min(surfW, surfH).toFloat()
            cx = surfW / 2f
            cy = surfH * 0.42f
            coverR = u * 0.27f * sCover
            maxBar = u * 0.10f
            glowR = coverR * 2.6f
            cardSide = u * 0.58f * sCover
            blobR = u * 0.9f
            fullRect.set(0, 0, surfW, surfH)
            computeCustomSrc()
            coverDirty = true
            shadersDirty = true
            textDirty = true
            for (i in 0 until STARS) resetStar(i, true)
            sweepShader = null
            for (i in 0 until PARTICLES) {
                px[i] = rnd.nextFloat() * surfW
                py[i] = rnd.nextFloat() * surfH
                pr[i] = u * (0.004f + rnd.nextFloat() * 0.010f)
                pv[i] = u * (0.02f + rnd.nextFloat() * 0.05f)
                pph[i] = rnd.nextFloat() * 6.28f
            }
        }

        // ================= Visualizer =================

        private fun ensureViz(now: Long) {
            if (viz != null || !visible) return
            if (now - lastVizTry < 4000L) return
            lastVizTry = now
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
            try {
                val v = Visualizer(0)
                v.setEnabled(false)
                val range = Visualizer.getCaptureSizeRange()
                v.setCaptureSize(1024.coerceIn(range[0], range[1]))
                v.setDataCaptureListener(fftListener, Visualizer.getMaxCaptureRate() / 2, false, true)
                v.setEnabled(true)
                viz = v
            } catch (_: Throwable) {
                viz = null
            }
        }

        private fun releaseViz() {
            val v = viz
            viz = null
            if (v != null) {
                try {
                    v.setEnabled(false)
                    v.release()
                } catch (_: Throwable) {
                }
            }
        }

        // ================= album art + colors =================

        private fun onArtChanged() {
            val a = MusicState.art
            art = a
            coverDirty = true
            if (prefAuto == AutoMode.PER_SONG && artSeenOnce) {
                val n = SystemClock.uptimeMillis()
                if (n - lastStyleSwitch > 3000L) switchStyleNext(n) // avoid double switches from several bumps per song
            }
            artSeenOnce = true
            if (a == null) {
                tiny = null
                artAccent = defAccent
                artSoft = defSoft
                artBg = defBg
                pickColors()
                return
            }
            try {
                tiny = Bitmap.createScaledBitmap(a, 32, 32, true)
                val small = Bitmap.createScaledBitmap(a, 64, 64, true)
                val p = Palette.from(small).maximumColorCount(16).generate()
                val dom = p.getDominantColor(defAccent)
                val acc = p.getVibrantColor(p.getLightVibrantColor(dom))
                val sft = p.getLightVibrantColor(p.getLightMutedColor(p.getMutedColor(acc)))
                val bg = p.getDarkMutedColor(p.getDarkVibrantColor(dom))
                artAccent = vivid(acc)
                artSoft = vivid(sft)
                artBg = deep(bg)
                if (colorDist(artAccent, artSoft) < 60) {
                    artSoft = vivid(shiftHue(artAccent, 40f))
                }
            } catch (_: Throwable) {
            }
            pickColors()
        }

        /** Picks target colors: ready-made theme or colors extracted from the cover. */
        private fun pickColors() {
            if (sColorMode in 1..Themes.list.size) {
                val th = Themes.list[sColorMode - 1]
                tgtAccent = th.accent
                tgtSoft = th.soft
                tgtBg = th.bg
            } else {
                tgtAccent = artAccent
                tgtSoft = artSoft
                tgtBg = artBg
            }
        }

        // ---------- background image from the gallery ----------

        private fun loadCustomBg(ver: Int) {
            loadedBgVer = ver
            customBg = try {
                val f = File(filesDir, Prefs.BG_FILE)
                if (f.exists()) BitmapFactory.decodeFile(f.absolutePath) else null
            } catch (_: Throwable) {
                null
            }
            computeCustomSrc()
        }

        /** Center-crops the image to the screen aspect ratio. */
        private fun computeCustomSrc() {
            val b = customBg ?: return
            if (surfW <= 0 || surfH <= 0) return
            val sr = surfW.toFloat() / surfH
            val br = b.width.toFloat() / b.height
            if (br > sr) {
                val nw = (b.height * sr).toInt().coerceIn(1, b.width)
                customSrc.set((b.width - nw) / 2, 0, (b.width + nw) / 2, b.height)
            } else {
                val nh = (b.width / sr).toInt().coerceIn(1, b.height)
                customSrc.set(0, (b.height - nh) / 2, b.width, (b.height + nh) / 2)
            }
        }

        private fun buildCover() {
            coverDirty = false
            val a = art
            if (a == null || coverR <= 0f) {
                coverBmp = null
                cardBmp = null
                return
            }
            val sq = min(a.width, a.height)
            squareSrc.set((a.width - sq) / 2, (a.height - sq) / 2, (a.width + sq) / 2, (a.height + sq) / 2)
            try {
                val d = (coverR * 2f).toInt().coerceAtLeast(2)
                val out = Bitmap.createBitmap(d, d, Bitmap.Config.ARGB_8888)
                val cv = Canvas(out)
                val p = Paint(Paint.ANTI_ALIAS_FLAG)
                p.isFilterBitmap = true
                cv.drawCircle(d / 2f, d / 2f, d / 2f, p)
                p.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
                cv.drawBitmap(a, squareSrc, RectF(0f, 0f, d.toFloat(), d.toFloat()), p)
                coverBmp = out
            } catch (_: Throwable) {
                coverBmp = null
            }
            try {
                val side = cardSide.toInt().coerceAtLeast(2)
                val out2 = Bitmap.createBitmap(side, side, Bitmap.Config.ARGB_8888)
                val cv2 = Canvas(out2)
                val p2 = Paint(Paint.ANTI_ALIAS_FLAG)
                p2.isFilterBitmap = true
                val rr = side * 0.08f
                val dst = RectF(0f, 0f, side.toFloat(), side.toFloat())
                cv2.drawRoundRect(dst, rr, rr, p2)
                p2.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
                cv2.drawBitmap(a, squareSrc, dst, p2)
                cardBmp = out2
            } catch (_: Throwable) {
                cardBmp = null
            }
        }

        private fun rebuildShaders() {
            shadersDirty = false
            builtAccent = curAccent
            builtBg = curBg
            builtSoft = curSoft
            bgPaint.shader = LinearGradient(
                0f, 0f, 0f, surfH.toFloat(),
                intArrayOf(mix(curBg, curAccent, 0.22f), curBg, mix(curBg, Color.BLACK, 0.65f)),
                floatArrayOf(0f, 0.55f, 1f),
                Shader.TileMode.CLAMP
            )
            glowShader = RadialGradient(
                0f, 0f, glowR,
                intArrayOf(curAccent, curAccent and 0x00FFFFFF),
                floatArrayOf(0f, 1f),
                Shader.TileMode.CLAMP
            )
            val blobCols = intArrayOf(curAccent, curSoft, mix(curSoft, Color.WHITE, 0.2f))
            for (k in 0 until 3) {
                blobShaders[k] = RadialGradient(
                    0f, 0f, blobR,
                    intArrayOf(blobCols[k], blobCols[k] and 0x00FFFFFF),
                    floatArrayOf(0f, 1f),
                    Shader.TileMode.CLAMP
                )
            }
            // Poster: fade the cover bottom into the background + top shadow so the status bar stays readable
            posterFadePaint.shader = LinearGradient(
                0f, u * 0.55f, 0f, u * 1.0f,
                intArrayOf(curBg and 0x00FFFFFF, curBg),
                null,
                Shader.TileMode.CLAMP
            )
            scrimPaint.shader = LinearGradient(
                0f, 0f, 0f, u * 0.28f,
                intArrayOf(Color.argb(140, 0, 0, 0), Color.argb(0, 0, 0, 0)),
                null,
                Shader.TileMode.CLAMP
            )
        }

        private fun refreshText() {
            val title = MusicState.title
            val artist = MusicState.artist
            val conn = MusicState.listenerConnected
            if (!textDirty && title == shownTitle && artist == shownArtist && conn == shownConn) return
            textDirty = false
            shownTitle = title
            shownArtist = artist
            shownConn = conn

            titlePaint.textSize = u * 0.058f
            artistPaint.textSize = u * 0.040f
            titlePaint.setShadowLayer(u * 0.010f, 0f, u * 0.004f, Color.argb(170, 0, 0, 0))
            artistPaint.setShadowLayer(u * 0.008f, 0f, u * 0.003f, Color.argb(170, 0, 0, 0))

            val l1: String
            val l2: String
            if (title.isNotEmpty()) {
                l1 = title
                l2 = artist
            } else if (!conn) {
                l1 = "Music Live Wallpaper"
                l2 = "Enable notification access in the app first"
            } else {
                l1 = "Music Live Wallpaper"
                l2 = "Play a song to start the show"
            }
            val maxW = u * 0.9f
            line1 = TextUtils.ellipsize(l1, titlePaint, maxW, TextUtils.TruncateAt.END).toString()
            line2 = TextUtils.ellipsize(l2, artistPaint, maxW, TextUtils.TruncateAt.END).toString()
        }

        // ================= drawing =================

        private fun drawFrame() {
            syncVideo()
            if (videoActive) {
                drawVideoOverlay()
                return
            }
            val holder = surfaceHolder ?: return
            var c: Canvas? = null
            try {
                c = try {
                    holder.lockHardwareCanvas()
                } catch (_: Throwable) {
                    holder.lockCanvas()
                }
                if (c != null) render(c)
            } catch (_: Throwable) {
            } finally {
                if (c != null) {
                    try {
                        holder.unlockCanvasAndPost(c)
                    } catch (_: Throwable) {
                    }
                }
            }
        }

        private fun simulate(t: Float) {
            // simulated beat (~114 BPM), used when the real audio cannot be read
            val beatPhase = (t * 1.9f) % 1f
            val kick = (1f - beatPhase).pow(4f)
            for (i in 0 until BANDS) {
                val f = i / BANDS.toFloat()
                val base = 0.18f + 0.28f * (0.5f + 0.5f * sin(t * (1.5f + f * 4f) + i * 0.7f))
                val boost = kick * (1f - f) * 0.5f
                target[i] = (base * (1f - f * 0.4f) + boost).coerceIn(0f, 1f)
            }
        }

        private fun render(c: Canvas) {
            if (surfW <= 0 || surfH <= 0 || u <= 0f) return
            val now = SystemClock.uptimeMillis()
            val dt = if (lastNow == 0L) 0.033f else (now - lastNow).coerceIn(1L, 100L) / 1000f
            lastNow = now
            val t = (now - startTime) / 1000f
            val w = surfW.toFloat()
            val h = surfH.toFloat()
            val playing = MusicState.playing

            // --- update state ---
            if (MusicState.version != seenVersion) {
                seenVersion = MusicState.version
                onArtChanged()
            }
            if (coverDirty) buildCover()
            refreshText()

            if (playing) {
                lastPlayingTs = now
                ensureViz(now)
            } else if (viz != null && now - lastPlayingTs > 5000L) {
                releaseViz()
            }

            if (playing) {
                val real = viz != null && (now - lastVizSignal) < 1500L
                if (real) {
                    System.arraycopy(vizTarget, 0, target, 0, BANDS)
                } else {
                    simulate(t)
                }
            } else {
                java.util.Arrays.fill(target, 0f)
            }
            for (i in 0 until BANDS) {
                val tv = target[i] * sIntensity
                val k = if (tv > bands[i]) 0.55f else 0.14f
                bands[i] += (tv - bands[i]) * k
            }
            var bass = 0f
            for (i in 0 until 6) bass += bands[i]
            bass /= 6f
            level += (bass - level) * 0.35f
            bassAvg += (bass - bassAvg) * 0.04f
            if (playing && bass > 0.28f && bass > bassAvg * 1.3f && now - lastRing > 320L) {
                ringBirths.add(now)
                lastRing = now
                if (ringBirths.size > 6) ringBirths.removeAt(0)
                onBeat(now, bass)
            }
            punch *= exp(-dt * 6f)
            flash *= exp(-dt * 9f)
            for (i in 0 until BANDS) peaks[i] = max(peaks[i] - dt * 0.55f, bands[i])
            updateSparks(dt)
            if (playing) {
                rotation = (rotation + (dt * 14f + level * dt * 40f) * sRot) % 360f
            }

            val kc = 1f - exp(-dt * 4f)
            curAccent = chase(curAccent, tgtAccent, kc)
            curSoft = chase(curSoft, tgtSoft, kc)
            curBg = chase(curBg, tgtBg, kc)
            if (shadersDirty || curAccent != builtAccent || curBg != builtBg || curSoft != builtSoft) {
                rebuildShaders()
            }

            // --- automatic style switching by time ---
            if (prefAuto == AutoMode.TIMED && now - lastStyleSwitch > AUTO_INTERVAL_MS) switchStyleNext(now)

            // the full-width poster would hide the video, so it falls back to the blur card
            val eff = if (videoActive && activeStyle == Styles.POSTER) Styles.BLUR_CARD else activeStyle

            // --- beat punch: zoom + shake around the whole scene ---
            c.save()
            if (punch > 0.01f && sFx > 0f) {
                val fxk = min(sFx, 1.6f)
                val amp = u * 0.004f * punch * fxk
                c.translate((rnd.nextFloat() - 0.5f) * 2f * amp, (rnd.nextFloat() - 0.5f) * 2f * amp)
                val z = 1f + 0.035f * punch * fxk
                c.scale(z, z, w / 2f, h / 2f)
            }
            when (eff) {
                Styles.BLUR_CARD -> drawBlurCard(c, t, dt, playing)
                Styles.POSTER -> drawPoster(c, t, dt, playing)
                Styles.WAVE -> drawWave(c, t, dt, playing)
                Styles.AURORA -> drawAurora(c, t, dt, playing)
                Styles.EQ -> drawEq(c, t, dt, playing)
                Styles.GLASS -> drawLiquidGlass(c, t, dt, playing)
                Styles.HYPER -> drawHyper(c, t, dt, playing)
                Styles.LASERS -> drawLasers(c, t, dt, playing)
                Styles.ORBITS -> drawOrbits(c, t, dt, playing)
                else -> drawVinyl(c, now, t, dt, playing)
            }
            drawFx(c, now)
            c.restore()

            // --- beat flash ---
            if (flash > 0.02f && sFx > 0f) {
                val fa = min(70f, flash * 80f * sFx).toInt().coerceIn(0, 255)
                flashPaint.color = (mix(curAccent, Color.WHITE, 0.55f) and 0x00FFFFFF) or (fa shl 24)
                c.drawRect(0f, 0f, w, h, flashPaint)
            }

            // --- fade-in when the style changes ---
            val fe = now - fadeStart
            if (fe in 0L until FADE_MS) {
                val a = (255f * (1f - fe / FADE_MS.toFloat())).toInt().coerceIn(0, 255)
                fadePaint.color = Color.argb(a, 0, 0, 0)
                c.drawRect(0f, 0f, w, h, fadePaint)
            }
        }

        // ================= style management =================

        private fun applyPrefs() {
            val n = SystemClock.uptimeMillis()
            val newStyle = Prefs.style(prefs)
            val newAuto = Prefs.auto(prefs)
            if (newStyle != prefStyle || newAuto != prefAuto) {
                prefStyle = newStyle
                prefAuto = newAuto
                activeStyle = prefStyle
                lastStyleSwitch = n
                fadeStart = n
            }
            sIntensity = Prefs.getInt(prefs, Prefs.INTENSITY, 100) / 100f
            sParts = (PARTICLES * Prefs.getInt(prefs, Prefs.PARTS, 100) / 100).coerceIn(0, PARTICLES)
            sRot = Prefs.getInt(prefs, Prefs.ROT, 100) / 100f
            sText = prefs.getBoolean(Prefs.TEXT, true)
            sBgDim = Prefs.getInt(prefs, Prefs.BGDIM, 35) / 100f
            sFx = Prefs.getInt(prefs, Prefs.FX, 100) / 100f
            sVideoDim = Prefs.getInt(prefs, Prefs.VIDEO_DIM, 25) / 100f
            sVideoIdle = prefs.getBoolean(Prefs.VIDEO_IDLE, false)
            resolveVideo()

            val newColor = Prefs.getInt(prefs, Prefs.COLOR, 0)
            if (newColor != sColorMode) {
                sColorMode = newColor
                pickColors()
            }
            val newBg = Prefs.getInt(prefs, Prefs.BG, BgMode.DEFAULT)
            if (newBg != sBgMode) {
                sBgMode = newBg
                fadeStart = n
            }
            val ver = Prefs.getInt(prefs, Prefs.BGVER, 0)
            if (sBgMode == BgMode.IMAGE && (customBg == null || ver != loadedBgVer)) loadCustomBg(ver)

            val newCover = Prefs.getInt(prefs, Prefs.COVER, 100) / 100f
            if (newCover != sCover) {
                sCover = newCover
                layout()
            }
        }

        private fun switchStyleNext(now: Long) {
            activeStyle = (activeStyle + 1) % Styles.COUNT
            lastStyleSwitch = now
            fadeStart = now
        }

        // ================= shared building blocks =================

        private fun drawBg(c: Canvas, tinyAlpha: Int) {
            val w = surfW.toFloat()
            val h = surfH.toFloat()
            val cbg = customBg
            if (videoActive) {
                // the video is the background: only dim it a little so the effects stay readable
                bgDimPaint.color = Color.argb((sVideoDim * 255f).toInt().coerceIn(0, 255), 0, 0, 0)
                c.drawRect(0f, 0f, w, h, bgDimPaint)
                return
            }
            if (sBgMode == BgMode.BLACK) {
                c.drawColor(Color.BLACK)
                return
            }
            if (sBgMode == BgMode.IMAGE && cbg != null) {
                c.drawBitmap(cbg, customSrc, fullRect, customPaint)
                bgDimPaint.color = Color.argb((sBgDim * 255f).toInt().coerceIn(0, 255), 0, 0, 0)
                c.drawRect(0f, 0f, w, h, bgDimPaint)
                return
            }
            c.drawRect(0f, 0f, w, h, bgPaint)
            val tn = tiny
            if (tn != null && tinyAlpha > 0) {
                tinyPaint.alpha = tinyAlpha
                c.drawBitmap(tn, null, fullRect, tinyPaint)
            }
        }

        private fun drawGlow(c: Canvas, gx: Float, gy: Float, k: Float) {
            c.save()
            c.translate(gx, gy)
            val gs = (1f + level * 0.25f) * k
            c.scale(gs, gs)
            glowPaint.shader = glowShader
            glowPaint.alpha = (70f + 150f * level).toInt().coerceIn(0, 255)
            c.drawCircle(0f, 0f, glowR, glowPaint)
            c.restore()
        }

        private fun drawParticles(c: Canvas, t: Float, dt: Float, playing: Boolean) {
            val w = surfW.toFloat()
            val h = surfH.toFloat()
            val speedMul = if (playing) 1f + level * 3f else 0.4f
            for (i in 0 until sParts) {
                py[i] -= pv[i] * speedMul * dt
                px[i] += sin(t * 0.7f + pph[i]) * u * 0.02f * dt
                if (py[i] < -pr[i]) {
                    py[i] = h + pr[i]
                    px[i] = rnd.nextFloat() * w
                }
                val alpha = (40f + 90f * (0.5f + 0.5f * sin(t * 1.3f + pph[i]))).toInt()
                val col = if (i % 2 == 0) curAccent else curSoft
                particlePaint.color = (col and 0x00FFFFFF) or (alpha shl 24)
                c.drawCircle(px[i], py[i], pr[i], particlePaint)
            }
        }

        private fun drawTitle(c: Canvas, ty: Float) {
            if (!sText) return
            if (punch > 0.12f && sFx > 0f) {
                // chromatic split on the beat
                val dx = u * 0.007f * punch * min(sFx, 1.6f)
                titlePaint.color = (curAccent and 0x00FFFFFF) or (170 shl 24)
                c.drawText(line1, cx - dx, ty, titlePaint)
                titlePaint.color = (curSoft and 0x00FFFFFF) or (170 shl 24)
                c.drawText(line1, cx + dx, ty, titlePaint)
                titlePaint.color = Color.WHITE
            }
            c.drawText(line1, cx, ty, titlePaint)
            if (line2.isNotEmpty()) {
                c.drawText(line2, cx, ty + u * 0.065f, artistPaint)
            }
        }

        /** Draws the rounded-square cover with side sd centered at (x, y). */
        private fun drawCardAt(c: Canvas, x: Float, y: Float, sd: Float) {
            val cb = cardBmp
            val hf = sd / 2f
            val rr = sd * 0.08f
            if (cb != null) {
                tmpRect.set(x - hf, y - hf, x + hf, y + hf)
                c.drawBitmap(cb, null, tmpRect, coverPaint)
            } else {
                fillPaint.color = mix(curBg, curAccent, 0.45f)
                c.drawRoundRect(x - hf, y - hf, x + hf, y + hf, rr, rr, fillPaint)
                notePaint.textSize = sd * 0.5f
                c.drawText("♪", x, y + sd * 0.17f, notePaint)
            }
            strokePaint.strokeWidth = max(1f, u * 0.003f)
            c.drawRoundRect(x - hf, y - hf, x + hf, y + hf, rr, rr, strokePaint)
        }

        /**
         * Horizontal spectrum bars: center = bass, edges = treble.
         * mirror=false: grow upward from line y / mirror=true: grow both ways from the center line y.
         */
        private fun drawBars(c: Canvas, y: Float, n: Int, maxLen: Float, mirror: Boolean, widthFrac: Float = 0.88f) {
            val totalW = surfW * widthFrac
            val step = totalW / n
            val x0 = (surfW - totalW) / 2f + step / 2f
            barPaint.strokeWidth = step * 0.55f
            val mid = (n - 1) / 2f
            val capR = step * 0.28f
            val gap = u * 0.012f
            fillPaint.color = Color.argb(190, 255, 255, 255)
            for (i in 0 until n) {
                val f = abs(i - mid) / mid
                val idx = min((f * (BANDS - 1) * 0.85f).toInt(), BANDS - 1)
                val band = bands[idx]
                val len = u * 0.006f + band * maxLen
                barPaint.color = mix(curAccent, curSoft, f)
                val x = x0 + i * step
                if (mirror) c.drawLine(x, y - len, x, y + len, barPaint)
                else c.drawLine(x, y, x, y - len, barPaint)
                // falling peak caps
                val pk = u * 0.006f + peaks[idx] * maxLen
                c.drawCircle(x, y - pk - gap, capR, fillPaint)
                if (mirror) c.drawCircle(x, y + pk + gap, capR, fillPaint)
            }
        }

        // ================= style 0: vinyl =================

        private fun drawVinyl(c: Canvas, now: Long, t: Float, dt: Float, playing: Boolean) {
            val h = surfH.toFloat()
            drawBg(c, 70)
            fxX = cx
            fxY = cy
            drawGlow(c, cx, cy, 1f)
            drawParticles(c, t, dt, playing)

            // --- rings expanding with the beat ---
            var ri = ringBirths.size - 1
            while (ri >= 0) {
                val age = (now - ringBirths[ri]) / 1800f
                if (age >= 1f) {
                    ringBirths.removeAt(ri)
                } else {
                    val r = coverR * (1.25f + age * 1.3f)
                    val a = ((1f - age) * (1f - age) * 150f).toInt()
                    ringPaint.color = (curAccent and 0x00FFFFFF) or (a shl 24)
                    ringPaint.strokeWidth = max(1f, u * 0.008f * (1f - age))
                    c.drawCircle(cx, cy, r, ringPaint)
                }
                ri--
            }

            // --- spectrum bars around the cover ---
            val inner = coverR * (1.10f + 0.05f * level)
            barPaint.strokeWidth = u * 0.011f
            val half = BARS / 2
            for (i in 0 until BARS) {
                val k = if (i < half) i else BARS - 1 - i
                val band = bands[min(k, BANDS - 1)]
                val len = u * 0.012f + band * maxBar
                barPaint.color = mix(curAccent, curSoft, k / (half - 1f))
                val x0 = cx + cosT[i] * inner
                val y0 = cy + sinT[i] * inner
                c.drawLine(x0, y0, cx + cosT[i] * (inner + len), cy + sinT[i] * (inner + len), barPaint)
            }

            // --- album cover (spins like a record + pumps with the bass) ---
            val s = 1f + 0.05f * level
            c.save()
            c.translate(cx, cy)
            c.scale(s, s)
            val cb = coverBmp
            if (cb != null) {
                c.save()
                c.rotate(rotation)
                c.drawBitmap(cb, -cb.width / 2f, -cb.height / 2f, coverPaint)
                c.restore()
            } else {
                fillPaint.color = mix(curBg, curAccent, 0.45f)
                c.drawCircle(0f, 0f, coverR, fillPaint)
                notePaint.textSize = coverR * 0.9f
                c.drawText("♪", 0f, coverR * 0.30f, notePaint)
            }
            strokePaint.strokeWidth = max(1f, u * 0.004f)
            c.drawCircle(0f, 0f, coverR, strokePaint)
            fillPaint.color = curBg
            c.drawCircle(0f, 0f, coverR * 0.11f, fillPaint)
            c.drawCircle(0f, 0f, coverR * 0.11f, strokePaint)
            c.restore()

            val ty = min(cy + coverR * 1.1f + maxBar + u * 0.10f, h - u * 0.16f)
            drawTitle(c, ty)
        }

        // ================= style 1: blur card =================

        private fun drawBlurCard(c: Canvas, t: Float, dt: Float, playing: Boolean) {
            val h = surfH.toFloat()
            drawBg(c, 215)
            if (!videoActive) c.drawRect(0f, 0f, surfW.toFloat(), h, dimPaint)
            drawParticles(c, t, dt, playing)
            val ccy = h * 0.40f
            fxX = cx
            fxY = ccy
            drawGlow(c, cx, ccy, 0.9f)
            val sd = cardSide * (1f + 0.045f * level)
            drawCardAt(c, cx, ccy, sd)
            drawBars(c, h * 0.93f, 40, u * 0.16f, false)
            drawTitle(c, ccy + cardSide / 2f + u * 0.11f)
        }

        // ================= style 2: full poster =================

        private fun drawPoster(c: Canvas, t: Float, dt: Float, playing: Boolean) {
            val w = surfW.toFloat()
            val h = surfH.toFloat()
            drawBg(c, 0)
            drawParticles(c, t, dt, playing)
            val side = u
            fxX = w / 2f
            fxY = side * 0.5f
            val a = art
            c.save()
            val s = 1f + 0.03f * level
            c.scale(s, s, w / 2f, 0f)
            if (a != null) {
                tmpRect.set((w - side) / 2f, 0f, (w + side) / 2f, side)
                c.drawBitmap(a, squareSrc, tmpRect, coverPaint)
            } else {
                fillPaint.color = mix(curBg, curAccent, 0.45f)
                c.drawRect((w - side) / 2f, 0f, (w + side) / 2f, side, fillPaint)
                notePaint.textSize = side * 0.4f
                c.drawText("♪", w / 2f, side * 0.55f, notePaint)
            }
            c.restore()
            if (sBgMode == BgMode.DEFAULT) c.drawRect(0f, side * 0.55f, w, side * 1.01f, posterFadePaint)
            c.drawRect(0f, 0f, w, side * 0.28f, scrimPaint)
            drawBars(c, h * 0.93f, 36, u * 0.20f, false)
            drawTitle(c, side * 1.10f)
        }

        // ================= style 3: sound waves =================

        private fun drawWave(c: Canvas, t: Float, dt: Float, playing: Boolean) {
            val w = surfW.toFloat()
            val h = surfH.toFloat()
            drawBg(c, 60)
            drawParticles(c, t, dt, playing)
            val ccy = h * 0.33f
            fxX = cx
            fxY = ccy
            drawGlow(c, cx, ccy, 0.8f)
            drawCardAt(c, cx, ccy, u * 0.44f * sCover * (1f + 0.05f * level))
            drawTitle(c, ccy + u * 0.22f * sCover + u * 0.12f)

            val n = 56
            for (layer in 0 until 3) {
                val baseY = h * (0.78f + 0.04f * layer)
                wavePath.reset()
                wavePath.moveTo(0f, h)
                for (j in 0..n) {
                    val f = j / n.toFloat()
                    val k = min((abs(f - 0.5f) * 2f * (BANDS - 1) * 0.8f).toInt(), BANDS - 1)
                    val amp = bands[k] * u * (0.20f - layer * 0.045f)
                    val wob = sin(f * 6.283f * (1.5f + layer * 0.7f) + t * (1.2f + layer * 0.5f) + layer * 1.7f) *
                        u * 0.012f * (1f + level * 2f)
                    wavePath.lineTo(f * w, baseY - amp + wob)
                }
                wavePath.lineTo(w, h)
                wavePath.close()
                val col = when (layer) {
                    0 -> curAccent
                    1 -> curSoft
                    else -> mix(curBg, curAccent, 0.45f)
                }
                val alpha0 = when (layer) {
                    0 -> 140
                    1 -> 150
                    else -> 235
                }
                val alpha = if (videoActive) (alpha0 * 0.6f).toInt() else alpha0
                fillPaint.color = (col and 0x00FFFFFF) or (alpha shl 24)
                c.drawPath(wavePath, fillPaint)
            }
        }

        // ================= style 4: aurora =================

        private fun drawAurora(c: Canvas, t: Float, dt: Float, playing: Boolean) {
            val w = surfW.toFloat()
            val h = surfH.toFloat()
            drawBg(c, 0)
            for (k in 0 until 3) {
                val ph = k * 2.1f
                val bx = cx + cos(t * 0.27f + ph) * w * 0.32f
                val by = h * (0.28f + 0.18f * k) + sin(t * 0.21f + ph * 1.7f) * h * 0.10f
                val sc = 0.8f + level * 0.9f + 0.15f * sin(t * 0.5f + ph)
                c.save()
                c.translate(bx, by)
                c.scale(sc, sc)
                glowPaint.shader = blobShaders[k]
                glowPaint.alpha = ((120f + 110f * level) * vk()).toInt().coerceIn(0, 255)
                c.drawCircle(0f, 0f, blobR, glowPaint)
                c.restore()
            }
            drawParticles(c, t, dt, playing)
            val ccy = h * 0.40f
            fxX = cx
            fxY = ccy
            val sd = u * 0.50f * sCover * (1f + 0.04f * level)
            drawCardAt(c, cx, ccy, sd)
            drawTitle(c, ccy + u * 0.25f * sCover + u * 0.11f)
        }

        // ================= style 5: equalizer =================

        private fun drawEq(c: Canvas, t: Float, dt: Float, playing: Boolean) {
            val h = surfH.toFloat()
            drawBg(c, 50)
            drawParticles(c, t, dt, playing)
            val midY = h * 0.46f
            val maxLen = u * 0.30f
            fxX = cx
            fxY = midY
            drawGlow(c, cx, midY, 1.1f)
            drawBars(c, midY, 32, maxLen, true)
            drawCardAt(c, cx, h * 0.20f, u * 0.30f * sCover * (1f + 0.05f * level))
            drawTitle(c, midY + maxLen + u * 0.13f)
        }

        // ================= video =================

        private fun vk(): Float = if (videoActive) 0.45f else 1f

        private var lastVideoUri: String? = null
        private var lastVideoPos = 0
        private var glassShaderW = 0f
        private var glassShaderH = 0f
        private var tunnelPhase = 0f
        private var orbitAngle = 0f

        /** Decides which video (if any) belongs to the current song. */
        private fun resolveVideo() {
            desiredVideo = if (prefs.getBoolean(Prefs.VIDEO_ON, false)) {
                VideoLibrary.resolve(prefs, MusicState.title, MusicState.artist)
            } else {
                null
            }
            if (desiredVideo != videoBrokenUri) videoBrokenUri = null
        }

        /** Starts / stops / switches the video player to match the current state. */
        private fun syncVideo() {
            if (MusicState.trackVersion != seenTrack) {
                seenTrack = MusicState.trackVersion
                resolveVideo()
            }
            val uri = desiredVideo
            val want = visible && surfaceReady && uri != null && uri != videoBrokenUri
            if (uri != null && want) {
                if (!videoActive) {
                    startVideo(uri)
                } else {
                    val g = videoGl
                    if (g != null) {
                        if (g.currentUri != uri) g.setVideo(uri, 0)
                        g.setPlaying(MusicState.playing || sVideoIdle)
                    }
                }
            } else if (videoActive) {
                stopVideo()
            }
        }

        private fun startVideo(uri: String) {
            val holder = surfaceHolder ?: return
            val surf = holder.surface ?: return
            if (!surf.isValid || surfW <= 0 || surfH <= 0) return
            var ref: VideoGl? = null
            val g = VideoGl(applicationContext) { _ ->
                // runs on the main thread; ignore callbacks of an older player
                if (videoGl != null && videoGl === ref) {
                    videoBrokenUri = desiredVideo
                    stopVideo()
                }
            }
            ref = g
            videoGl = g
            videoActive = true
            g.start(surf, surfW, surfH)
            g.setVideo(uri, if (uri == lastVideoUri) lastVideoPos else 0)
            g.setPlaying(MusicState.playing || sVideoIdle)
        }

        private fun stopVideo() {
            val g = videoGl ?: return
            videoGl = null
            videoActive = false
            g.stop()
            lastVideoUri = g.currentUri
            lastVideoPos = g.lastPosition
        }

        /** Draws the effects (transparent background) into the overlay bitmap that is composited over the video. */
        private fun drawVideoOverlay() {
            val g = videoGl ?: return
            if (surfW <= 0 || surfH <= 0) return
            val sc = min(1f, OVERLAY_MAX_SIDE / min(surfW, surfH).toFloat())
            val ow = (surfW * sc).toInt().coerceAtLeast(2)
            val oh = (surfH * sc).toInt().coerceAtLeast(2)
            if (ow != ovW || oh != ovH) {
                ovW = ow
                ovH = oh
            }
            g.ensureOverlay(ow, oh)
            val bmp = g.backBuffer() ?: return
            bmp.eraseColor(Color.TRANSPARENT)
            val cv = Canvas(bmp)
            cv.scale(ow / surfW.toFloat(), oh / surfH.toFloat())
            try {
                render(cv)
            } catch (_: Throwable) {
            }
            g.commit(curBg)
        }

        // ================= crazy FX =================

        private fun onBeat(now: Long, strength: Float) {
            val st = (strength * 1.4f).coerceIn(0.4f, 1f)
            punch = max(punch, st)
            flash = max(flash, st)
            if (sFx <= 0f) return
            shockBirth[shockNext] = now
            shockX[shockNext] = fxX
            shockY[shockNext] = fxY
            shockStr[shockNext] = st
            shockNext = (shockNext + 1) % SHOCKS
            val n = (10f + 16f * st * min(sFx, 1.6f)).toInt().coerceAtMost(46)
            for (k in 0 until n) {
                val i = spNext
                spNext = (spNext + 1) % SPARKS
                val a = rnd.nextFloat() * 6.2832f
                val sp = u * (0.35f + rnd.nextFloat() * 0.9f) * (0.7f + st * 0.6f)
                spX[i] = fxX
                spY[i] = fxY
                spVx[i] = cos(a) * sp
                spVy[i] = sin(a) * sp
                spMax[i] = 0.55f + rnd.nextFloat() * 0.6f
                spLife[i] = spMax[i]
                spCol[i] = when (rnd.nextInt(3)) {
                    0 -> curAccent
                    1 -> curSoft
                    else -> Color.WHITE
                }
            }
        }

        private fun updateSparks(dt: Float) {
            val drag = exp(-dt * 2.2f)
            for (i in 0 until SPARKS) {
                if (spLife[i] <= 0f) continue
                spLife[i] -= dt
                spX[i] += spVx[i] * dt
                spY[i] += spVy[i] * dt
                spVx[i] *= drag
                spVy[i] = spVy[i] * drag + u * 0.25f * dt
            }
        }

        /** Shockwave rings + beat sparks, drawn on top of every style. */
        private fun drawFx(c: Canvas, now: Long) {
            if (sFx <= 0f) return
            val k = min(sFx, 1.6f)
            for (i in 0 until SHOCKS) {
                val b = shockBirth[i]
                if (b == 0L) continue
                val age = (now - b) / 1100f
                if (age >= 1f) {
                    shockBirth[i] = 0L
                    continue
                }
                val r = u * (0.06f + age * 0.85f)
                val fade = (1f - age) * (1f - age)
                val a = (fade * 190f * shockStr[i] * k).toInt().coerceIn(0, 255)
                val sw = max(1.5f, u * 0.022f * (1f - age) * shockStr[i])
                ringPaint.strokeWidth = sw
                ringPaint.color = (curAccent and 0x00FFFFFF) or (a shl 24)
                c.drawCircle(shockX[i], shockY[i], r, ringPaint)
                ringPaint.strokeWidth = sw * 0.6f
                ringPaint.color = (curSoft and 0x00FFFFFF) or ((a * 0.7f).toInt() shl 24)
                c.drawCircle(shockX[i], shockY[i], r * 0.955f, ringPaint)
                ringPaint.strokeWidth = max(1f, sw * 0.3f)
                ringPaint.color = 0x00FFFFFF or ((a * 0.5f).toInt() shl 24)
                c.drawCircle(shockX[i], shockY[i], r * 1.045f, ringPaint)
            }
            for (i in 0 until SPARKS) {
                val life = spLife[i]
                if (life <= 0f) continue
                val f = (life / spMax[i]).coerceIn(0f, 1f)
                val a = (f * f * 255f).toInt().coerceIn(0, 255)
                sparkPaint.color = (spCol[i] and 0x00FFFFFF) or (a shl 24)
                sparkPaint.strokeWidth = max(1.5f, u * 0.007f * f)
                c.drawLine(spX[i] - spVx[i] * 0.035f, spY[i] - spVy[i] * 0.035f, spX[i], spY[i], sparkPaint)
            }
        }

        private fun ensureSweep() {
            if (sweepShader != null) return
            val bw = u * 0.45f
            val sh = LinearGradient(
                0f, 0f, bw, 0f,
                intArrayOf(0x00FFFFFF, 0x66FFFFFF, 0x00FFFFFF),
                floatArrayOf(0f, 0.5f, 1f),
                Shader.TileMode.CLAMP
            )
            sweepShader = sh
            sweepPaint.shader = sh
        }

        /** A diagonal glossy light band that sweeps across the screen every few seconds. */
        private fun drawSweep(c: Canvas, t: Float, alpha: Int) {
            ensureSweep()
            val w = surfW.toFloat()
            val h = surfH.toFloat()
            val period = 5.5f
            val ph = (t % period) / period
            val x = -u * 0.5f + ph * (w + u)
            c.save()
            c.rotate(18f, w / 2f, h / 2f)
            c.translate(x, -h * 0.3f)
            sweepPaint.alpha = alpha
            c.drawRect(0f, 0f, u * 0.45f, h * 1.6f, sweepPaint)
            c.restore()
        }

        /** Round cover without the vinyl hole (used by Hyperspace and Orbits). */
        private fun drawCoverDisc(c: Canvas, x: Float, y: Float, scale: Float, rot: Float) {
            c.save()
            c.translate(x, y)
            c.scale(scale, scale)
            val cb = coverBmp
            if (cb != null) {
                c.save()
                c.rotate(rot)
                c.drawBitmap(cb, -cb.width / 2f, -cb.height / 2f, coverPaint)
                c.restore()
            } else {
                fillPaint.color = mix(curBg, curAccent, 0.45f)
                c.drawCircle(0f, 0f, coverR, fillPaint)
                notePaint.textSize = coverR * 0.9f
                c.drawText("♪", 0f, coverR * 0.30f, notePaint)
            }
            strokePaint.strokeWidth = max(1f, u * 0.004f)
            c.drawCircle(0f, 0f, coverR, strokePaint)
            c.restore()
        }

        // ================= style 6: liquid glass =================

        private fun drawLiquidGlass(c: Canvas, t: Float, dt: Float, playing: Boolean) {
            val w = surfW.toFloat()
            val h = surfH.toFloat()
            drawBg(c, 150)
            // gel blobs drifting behind the glass
            for (k in 0 until 3) {
                val ph = k * 2.3f
                val bx = cx + cos(t * 0.35f + ph) * w * 0.34f
                val by = h * (0.22f + 0.22f * k) + sin(t * 0.28f + ph * 1.6f) * h * 0.07f
                val sc = 0.55f + level * 0.55f + 0.10f * sin(t * 0.7f + ph)
                c.save()
                c.translate(bx, by)
                c.scale(sc, sc)
                glowPaint.shader = blobShaders[k]
                glowPaint.alpha = ((110f + 110f * level) * vk()).toInt().coerceIn(0, 255)
                c.drawCircle(0f, 0f, blobR, glowPaint)
                c.restore()
            }
            drawParticles(c, t, dt, playing)

            val pw = min(w * 0.94f, u * 0.84f * sCover)
            val ph = pw * 1.28f
            val pcy = h * 0.45f
            val rr = pw * 0.11f
            fxX = cx
            fxY = pcy - ph * 0.1f

            if (glassShaderW != pw || glassShaderH != ph) {
                glassShaderW = pw
                glassShaderH = ph
                glassGloss.shader = LinearGradient(
                    0f, -ph / 2f, 0f, ph / 2f,
                    intArrayOf(0x5AFFFFFF, 0x10FFFFFF, 0x00FFFFFF, 0x1CFFFFFF),
                    floatArrayOf(0f, 0.22f, 0.6f, 1f),
                    Shader.TileMode.CLAMP
                )
                glassRim.shader = LinearGradient(
                    -pw / 2f, -ph / 2f, pw / 2f, ph / 2f,
                    intArrayOf(0xE6FFFFFF.toInt(), 0x30FFFFFF, 0x30FFFFFF, 0xA0FFFFFF.toInt()),
                    floatArrayOf(0f, 0.35f, 0.65f, 1f),
                    Shader.TileMode.CLAMP
                )
            }

            // jelly wobble: squash & stretch that follows the bass
            val wob = sin(t * 2.1f)
            val sx = 1f + 0.012f * wob + 0.035f * level + 0.02f * punch
            val sy = 1f - 0.010f * wob - 0.020f * level - 0.012f * punch
            c.save()
            c.translate(cx, pcy)
            c.scale(sx, sy)
            glassRect.set(-pw / 2f, -ph / 2f, pw / 2f, ph / 2f)
            glassPath.reset()
            glassPath.addRoundRect(glassRect, rr, rr, Path.Direction.CW)

            c.save()
            c.clipPath(glassPath)
            val tn = tiny
            if (!videoActive && tn != null && sBgMode == BgMode.DEFAULT) {
                // frosted look: a blurred, brighter copy of the cover colors inside the glass
                tmpRect.set(-cx, -pcy, w - cx, h - pcy)
                frostPaint.alpha = 255
                c.drawBitmap(tn, null, tmpRect, frostPaint)
            }
            glassWash.color = Color.argb(if (videoActive) 52 else 40, 255, 255, 255)
            c.drawRect(glassRect, glassWash)
            c.drawRect(glassRect, glassGloss)
            c.save()
            c.translate(-cx, -pcy)
            drawSweep(c, t, 150)
            c.restore()
            c.restore()

            glassRim.strokeWidth = max(1.5f, u * 0.004f)
            c.drawPath(glassPath, glassRim)

            val side = pw * 0.74f * (1f + 0.03f * level)
            val coverY = -ph / 2f + pw * 0.07f + pw * 0.37f
            drawCardAt(c, 0f, coverY, side)
            c.restore()

            drawTitle(c, pcy + coverY + pw * 0.37f + pw * 0.10f)
            drawBars(c, pcy + ph / 2f - pw * 0.07f, 30, ph * 0.12f, false, pw * 0.80f / w)
        }

        // ================= style 7: hyperspace =================

        private fun resetStar(i: Int, anywhere: Boolean) {
            val a = rnd.nextFloat() * 6.2832f
            val r = 0.08f + rnd.nextFloat() * 1.1f
            stX[i] = cos(a) * r
            stY[i] = sin(a) * r
            stZ[i] = if (anywhere) 0.05f + rnd.nextFloat() * 0.95f else 1f
        }

        private fun drawHyper(c: Canvas, t: Float, dt: Float, playing: Boolean) {
            val w = surfW.toFloat()
            val h = surfH.toFloat()
            drawBg(c, 40)
            val ccy = h * 0.40f
            fxX = cx
            fxY = ccy
            val speed = 0.10f + level * 1.6f + (if (playing) 0.12f else 0f)
            tunnelPhase = (tunnelPhase + dt * (0.18f + level * 0.9f)) % 1f

            // tunnel rings rushing outward
            for (i in 0 until 5) {
                val p = (tunnelPhase + i / 5f) % 1f
                val r = u * (0.18f + p * p * 1.25f)
                val a = ((1f - p) * 70f * (0.5f + level)).toInt().coerceIn(0, 255)
                ringPaint.strokeWidth = max(1f, u * 0.004f * (0.5f + p * 2f))
                ringPaint.color = (mix(curAccent, curSoft, p) and 0x00FFFFFF) or (a shl 24)
                c.drawCircle(cx, ccy, r, ringPaint)
            }

            // warp stars
            val scale = u * 0.16f
            for (i in 0 until STARS) {
                stZ[i] -= speed * dt * 0.6f
                val z = stZ[i]
                if (z < 0.03f) {
                    resetStar(i, false)
                    continue
                }
                val sx = cx + stX[i] / z * scale
                val sy = ccy + stY[i] / z * scale
                if (sx < -60f || sx > w + 60f || sy < -60f || sy > h + 60f) {
                    resetStar(i, false)
                    continue
                }
                val zt = z + speed * dt * 0.6f * (2.5f + level * 6f)
                val tx = cx + stX[i] / zt * scale
                val ty = ccy + stY[i] / zt * scale
                val kk = 1f - z
                val col = mix(curSoft, Color.WHITE, kk)
                val a = (40f + kk * 260f).toInt().coerceIn(0, 255)
                barPaint.strokeWidth = max(1f, u * 0.006f * kk * kk * 3f)
                barPaint.color = (col and 0x00FFFFFF) or (a shl 24)
                c.drawLine(tx, ty, sx, sy, barPaint)
            }

            drawGlow(c, cx, ccy, 0.9f)
            // chromatic rings around the disc
            val ds = 0.85f * (1f + 0.08f * level + 0.05f * punch)
            val off = u * 0.006f * (1f + punch * 3f)
            ringPaint.strokeWidth = max(1.5f, u * 0.004f)
            ringPaint.color = (curAccent and 0x00FFFFFF) or (150 shl 24)
            c.drawCircle(cx - off, ccy, coverR * ds * 1.06f, ringPaint)
            ringPaint.color = (curSoft and 0x00FFFFFF) or (150 shl 24)
            c.drawCircle(cx + off, ccy, coverR * ds * 1.06f, ringPaint)
            drawCoverDisc(c, cx, ccy, ds, rotation * 0.3f)
            drawTitle(c, min(ccy + coverR * 1.05f + u * 0.12f, h - u * 0.16f))
        }

        // ================= style 8: neon lasers =================

        private fun drawLasers(c: Canvas, t: Float, dt: Float, playing: Boolean) {
            val w = surfW.toFloat()
            val h = surfH.toFloat()
            drawBg(c, 55)
            val cardY = h * 0.30f
            fxX = cx
            fxY = cardY
            val baseY = h * 0.93f
            val n = 9
            for (i in 0 until n) {
                val f = i / (n - 1f)
                val band = bands[min((abs(f - 0.5f) * 2f * (BANDS - 1) * 0.7f).toInt(), BANDS - 1)]
                val ang = -1.5708f + (f - 0.5f) * 1.9f * (0.7f + 0.5f * sin(t * 0.6f + i)) +
                    sin(t * 0.9f + i * 1.3f) * 0.25f
                val len = u * 1.8f
                val ex = cx + cos(ang) * len
                val ey = baseY + sin(ang) * len
                val a = (50f + 170f * band).toInt().coerceIn(0, 255)
                val col = when (i % 3) {
                    0 -> curAccent
                    1 -> curSoft
                    else -> mix(curSoft, Color.WHITE, 0.6f)
                }
                barPaint.strokeWidth = u * (0.03f + 0.02f * band)
                barPaint.color = (col and 0x00FFFFFF) or ((a / 4) shl 24)
                c.drawLine(cx, baseY, ex, ey, barPaint)
                barPaint.strokeWidth = max(1.5f, u * 0.006f)
                barPaint.color = (col and 0x00FFFFFF) or (a shl 24)
                c.drawLine(cx, baseY, ex, ey, barPaint)
            }
            // two scanning beams from the top corners
            for (side in 0 until 2) {
                val sxp = if (side == 0) 0f else w
                val dir = if (side == 0) 1f else -1f
                val ang = 1.5708f - dir * (0.55f + 0.35f * sin(t * 0.8f + side * 2f) + level * 0.3f)
                val ex = sxp + cos(ang) * u * 1.8f
                val ey = sin(ang) * u * 1.8f
                barPaint.strokeWidth = max(1.5f, u * 0.005f)
                barPaint.color = (curSoft and 0x00FFFFFF) or (110 shl 24)
                c.drawLine(sxp, 0f, ex, ey, barPaint)
            }
            drawParticles(c, t, dt, playing)
            drawBars(c, h * 0.95f, 44, u * 0.16f, false)
            drawGlow(c, cx, cardY, 0.8f)
            drawCardAt(c, cx, cardY, u * 0.46f * sCover * (1f + 0.05f * level))
            drawTitle(c, cardY + u * 0.23f * sCover + u * 0.12f)
        }

        // ================= style 9: orbits =================

        private fun drawOrbits(c: Canvas, t: Float, dt: Float, playing: Boolean) {
            val h = surfH.toFloat()
            drawBg(c, 60)
            val ccy = h * 0.42f
            fxX = cx
            fxY = ccy
            drawGlow(c, cx, ccy, 1f)
            drawParticles(c, t, dt, playing)
            orbitAngle += dt * (0.5f + level * 2.2f) * max(0.2f, sRot)

            for (o in 0 until 3) {
                val rx = u * (0.30f + o * 0.11f) * sCover
                val ry = rx * (0.38f + 0.05f * o)
                val tilt = o * 55f - 20f + sin(t * 0.3f + o) * 18f
                c.save()
                c.translate(cx, ccy)
                c.rotate(tilt)
                ringPaint.strokeWidth = max(1f, u * 0.003f)
                ringPaint.color = 0x00FFFFFF or (45 shl 24)
                tmpRect.set(-rx, -ry, rx, ry)
                c.drawOval(tmpRect, ringPaint)
                val dir = if (o % 2 == 0) 1f else -1f
                for (p in 0 until 3) {
                    val ang = orbitAngle * dir * (1f + o * 0.35f) + p * 2.0944f + o
                    val band = bands[min((o * 3 + p) * 3, BANDS - 1)]
                    val r = u * (0.012f + 0.022f * band + 0.008f * punch)
                    val col = mix(curAccent, curSoft, (p + o) / 5f)
                    for (k in 5 downTo 1) {
                        val a2 = ang - dir * k * 0.09f
                        val a = 70 - k * 11
                        fillPaint.color = (col and 0x00FFFFFF) or (a shl 24)
                        c.drawCircle(cos(a2) * rx, sin(a2) * ry, r * (1f - k * 0.13f), fillPaint)
                    }
                    val px2 = cos(ang) * rx
                    val py2 = sin(ang) * ry
                    fillPaint.color = (col and 0x00FFFFFF) or (70 shl 24)
                    c.drawCircle(px2, py2, r * 2.4f, fillPaint)
                    fillPaint.color = mix(col, Color.WHITE, 0.35f)
                    c.drawCircle(px2, py2, r, fillPaint)
                }
                c.restore()
            }
            drawCoverDisc(c, cx, ccy, 0.85f * (1f + 0.06f * level), rotation * 0.5f)
            drawTitle(c, min(ccy + u * 0.34f * sCover + u * 0.12f, h - u * 0.16f))
        }

    }
}
