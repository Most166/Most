package com.musicwall.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.SurfaceTexture
import android.media.MediaPlayer
import android.net.Uri
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLUtils
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.view.Surface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Plays a muted looping video on the wallpaper surface with OpenGL ES and draws the
 * wallpaper effects (rendered by Canvas into a bitmap) on top of it.
 *
 * Usage (main thread): start() -> setVideo() -> every frame: backBuffer() draw, commit() -> stop().
 * Everything that touches GL / MediaPlayer runs on one private HandlerThread.
 */
class VideoGl(
    private val ctx: Context,
    private val onFailed: (String) -> Unit
) {
    private val main = Handler(Looper.getMainLooper())
    private var thread: HandlerThread? = null
    private var gl: Handler? = null

    // ---- EGL / GL (GL thread only) ----
    private var eglDisplay: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var eglContext: EGLContext = EGL14.EGL_NO_CONTEXT
    private var eglSurface: EGLSurface = EGL14.EGL_NO_SURFACE
    private var progVideo = 0
    private var progOverlay = 0
    private var videoTex = 0
    private var overlayTex = 0
    private var texW = 0
    private var texH = 0
    private var surfW = 1
    private var surfH = 1
    private var st: SurfaceTexture? = null
    private var videoSurface: Surface? = null
    private var player: MediaPlayer? = null
    private var prepared = false
    private var hasFrame = false
    private var vidW = 0
    private var vidH = 0
    private val texMat = FloatArray(16)

    private val frameAvail = AtomicBoolean(false)
    private val drawPending = AtomicBoolean(false)

    @Volatile private var wantPlay = false
    @Volatile private var failed = false
    @Volatile var lastPosition: Int = 0
        private set
    @Volatile var currentUri: String? = null
        private set

    // ---- overlay double buffer (shared with the main thread) ----
    private val lock = Any()
    private var front: Bitmap? = null
    private var back: Bitmap? = null
    private var dirty = false
    @Volatile private var clearColor = 0xFF000000.toInt()

    private val quadPos: FloatBuffer = floatBuf(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f))
    private val uvVideo: FloatBuffer = floatBuf(floatArrayOf(0f, 0f, 1f, 0f, 0f, 1f, 1f, 1f))
    private val uvOverlay: FloatBuffer = floatBuf(floatArrayOf(0f, 1f, 1f, 1f, 0f, 0f, 1f, 0f))

    private fun floatBuf(a: FloatArray): FloatBuffer =
        ByteBuffer.allocateDirect(a.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
            put(a)
            position(0)
        }

    val isRunning: Boolean get() = gl != null && !failed

    // =================== public API (main thread) ===================

    fun start(surface: Surface, w: Int, h: Int) {
        if (thread != null) return
        failed = false
        val th = HandlerThread("wallpaper-gl").also { it.start() }
        thread = th
        val h2 = Handler(th.looper)
        gl = h2
        surfW = w
        surfH = h
        h2.post {
            try {
                initEgl(surface)
                initGl()
            } catch (t: Throwable) {
                fail("GL init failed: ${t.message}")
            }
        }
    }

    fun resize(w: Int, h: Int) {
        surfW = w
        surfH = h
    }

    fun setVideo(uri: String, startPos: Int) {
        val h = gl ?: return
        currentUri = uri
        h.post {
            try {
                openPlayer(Uri.parse(uri), startPos)
            } catch (t: Throwable) {
                fail("Video open failed: ${t.message}")
            }
        }
    }

    fun setPlaying(p: Boolean) {
        if (wantPlay == p) return
        wantPlay = p
        gl?.post { applyPlaying() }
    }

    /** Allocates the overlay buffers if the size changed. */
    fun ensureOverlay(w: Int, h: Int) {
        synchronized(lock) {
            val b = back
            if (b == null || b.width != w || b.height != h) {
                front = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                back = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                dirty = false
            }
        }
    }

    /** The bitmap the main thread should draw the next overlay frame into. */
    fun backBuffer(): Bitmap? = synchronized(lock) { back }

    /** Publishes the back buffer to the GL thread and asks for a redraw. */
    fun commit(clear: Int) {
        synchronized(lock) {
            val t = front
            front = back
            back = t
            dirty = true
            clearColor = clear
        }
        requestDraw()
    }

    /** Synchronous teardown: after this returns the surface can be used with Canvas again. */
    fun stop() {
        val h = gl
        val th = thread
        gl = null
        thread = null
        if (h == null || th == null) return
        h.removeCallbacksAndMessages(null)
        val latch = CountDownLatch(1)
        h.post {
            try {
                releaseAll()
            } catch (_: Throwable) {
            } finally {
                latch.countDown()
            }
        }
        try {
            latch.await(2000, TimeUnit.MILLISECONDS)
        } catch (_: InterruptedException) {
        }
        th.quitSafely()
        synchronized(lock) {
            front = null
            back = null
            dirty = false
        }
    }

    // =================== GL thread ===================

    private fun fail(msg: String) {
        if (failed) return
        failed = true
        main.post { onFailed(msg) }
    }

    private fun requestDraw() {
        val h = gl ?: return
        if (drawPending.compareAndSet(false, true)) h.post { draw() }
    }

    private fun initEgl(surface: Surface) {
        val d = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        check(d != EGL14.EGL_NO_DISPLAY) { "no display" }
        val ver = IntArray(2)
        check(EGL14.eglInitialize(d, ver, 0, ver, 1)) { "eglInitialize" }
        eglDisplay = d
        val cfgAttr = intArrayOf(
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8,
            EGL14.EGL_NONE
        )
        val cfgs = arrayOfNulls<EGLConfig>(1)
        val num = IntArray(1)
        check(EGL14.eglChooseConfig(d, cfgAttr, 0, cfgs, 0, 1, num, 0) && num[0] > 0) { "no config" }
        val cfg = cfgs[0]
        val ctxAttr = intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE)
        eglContext = EGL14.eglCreateContext(d, cfg, EGL14.EGL_NO_CONTEXT, ctxAttr, 0)
        check(eglContext != EGL14.EGL_NO_CONTEXT) { "eglCreateContext" }
        eglSurface = EGL14.eglCreateWindowSurface(d, cfg, surface, intArrayOf(EGL14.EGL_NONE), 0)
        check(eglSurface != EGL14.EGL_NO_SURFACE) { "eglCreateWindowSurface" }
        check(EGL14.eglMakeCurrent(d, eglSurface, eglSurface, eglContext)) { "eglMakeCurrent" }
    }

    private fun compile(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
        check(ok[0] != 0) { "shader: " + GLES20.glGetShaderInfoLog(s) }
        return s
    }

    private fun program(vs: String, fs: String): Int {
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, compile(GLES20.GL_VERTEX_SHADER, vs))
        GLES20.glAttachShader(p, compile(GLES20.GL_FRAGMENT_SHADER, fs))
        GLES20.glBindAttribLocation(p, 0, "aPos")
        GLES20.glBindAttribLocation(p, 1, "aUv")
        GLES20.glLinkProgram(p)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0)
        check(ok[0] != 0) { "link: " + GLES20.glGetProgramInfoLog(p) }
        return p
    }

    private fun initGl() {
        progVideo = program(
            """
            attribute vec2 aPos; attribute vec2 aUv;
            uniform mat4 uTex; uniform vec2 uCrop;
            varying vec2 vUv;
            void main() {
                gl_Position = vec4(aPos, 0.0, 1.0);
                vec2 c = (aUv - 0.5) * uCrop + 0.5;
                vUv = (uTex * vec4(c, 0.0, 1.0)).xy;
            }
            """.trimIndent(),
            """
            #extension GL_OES_EGL_image_external : require
            precision mediump float;
            varying vec2 vUv; uniform samplerExternalOES uSamp;
            void main() { gl_FragColor = texture2D(uSamp, vUv); }
            """.trimIndent()
        )
        progOverlay = program(
            """
            attribute vec2 aPos; attribute vec2 aUv; varying vec2 vUv;
            void main() { gl_Position = vec4(aPos, 0.0, 1.0); vUv = aUv; }
            """.trimIndent(),
            """
            precision mediump float;
            varying vec2 vUv; uniform sampler2D uSamp;
            void main() { gl_FragColor = texture2D(uSamp, vUv); }
            """.trimIndent()
        )
        val t = IntArray(2)
        GLES20.glGenTextures(2, t, 0)
        videoTex = t[0]
        overlayTex = t[1]
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, videoTex)
        texParams(GLES11Ext.GL_TEXTURE_EXTERNAL_OES)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, overlayTex)
        texParams(GLES20.GL_TEXTURE_2D)
        requestDraw()
    }

    private fun texParams(target: Int) {
        GLES20.glTexParameteri(target, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(target, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(target, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(target, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
    }

    private fun closePlayer() {
        lastPosition = try {
            player?.currentPosition ?: lastPosition
        } catch (_: Throwable) {
            lastPosition
        }
        try {
            player?.release()
        } catch (_: Throwable) {
        }
        player = null
        prepared = false
        hasFrame = false
        try {
            st?.release()
        } catch (_: Throwable) {
        }
        st = null
        try {
            videoSurface?.release()
        } catch (_: Throwable) {
        }
        videoSurface = null
        vidW = 0
        vidH = 0
    }

    private fun openPlayer(uri: Uri, startPos: Int) {
        if (videoTex == 0) {
            // GL not ready yet: retry shortly
            gl?.postDelayed({ if (!failed) openPlayer(uri, startPos) }, 30)
            return
        }
        closePlayer()
        frameAvail.set(false)
        // a fresh external texture for every player avoids stale SurfaceTexture state
        GLES20.glDeleteTextures(1, intArrayOf(videoTex), 0)
        val gen = IntArray(1)
        GLES20.glGenTextures(1, gen, 0)
        videoTex = gen[0]
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, videoTex)
        texParams(GLES11Ext.GL_TEXTURE_EXTERNAL_OES)
        val tex = SurfaceTexture(videoTex)
        tex.setOnFrameAvailableListener({
            frameAvail.set(true)
            requestDraw()
        }, gl)
        st = tex
        val surf = Surface(tex)
        videoSurface = surf
        val mp = MediaPlayer()
        player = mp
        mp.setSurface(surf)
        mp.setDataSource(ctx, uri)
        mp.isLooping = true
        mp.setVolume(0f, 0f)
        mp.setOnVideoSizeChangedListener { _, w, h ->
            vidW = w
            vidH = h
        }
        mp.setOnErrorListener { _, what, extra ->
            fail("Video error $what/$extra")
            true
        }
        mp.setOnPreparedListener { p ->
            prepared = true
            if (startPos > 0) {
                try {
                    p.seekTo(startPos)
                } catch (_: Throwable) {
                }
            }
            // start() makes the first frame appear; pause again right after if music is paused
            p.start()
            gl?.postDelayed({ applyPlaying() }, 200)
        }
        mp.prepareAsync()
    }

    private fun applyPlaying() {
        val mp = player ?: return
        if (!prepared) return
        try {
            if (wantPlay && !mp.isPlaying) mp.start()
            else if (!wantPlay && mp.isPlaying) mp.pause()
        } catch (_: Throwable) {
        }
    }

    private fun draw() {
        drawPending.set(false)
        if (eglSurface == EGL14.EGL_NO_SURFACE || progVideo == 0) return
        try {
            if (frameAvail.getAndSet(false)) {
                val s = st
                if (s != null) {
                    s.updateTexImage()
                    s.getTransformMatrix(texMat)
                    hasFrame = true
                }
            }
            uploadOverlay()

            val cc = clearColor
            GLES20.glViewport(0, 0, surfW, surfH)
            GLES20.glClearColor(
                ((cc shr 16) and 255) / 255f, ((cc shr 8) and 255) / 255f, (cc and 255) / 255f, 1f
            )
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
            GLES20.glDisable(GLES20.GL_BLEND)

            if (hasFrame && vidW > 0 && vidH > 0) drawVideo()
            if (texW > 0) drawOverlay()

            if (!EGL14.eglSwapBuffers(eglDisplay, eglSurface)) {
                val err = EGL14.eglGetError()
                if (err != EGL14.EGL_SUCCESS) fail("eglSwapBuffers 0x${Integer.toHexString(err)}")
            }
        } catch (t: Throwable) {
            fail("GL draw failed: ${t.message}")
        }
    }

    private fun drawVideo() {
        GLES20.glUseProgram(progVideo)
        val sa = surfW.toFloat() / surfH
        val va = vidW.toFloat() / vidH
        val cx: Float
        val cy: Float
        if (va > sa) {
            cx = sa / va
            cy = 1f
        } else {
            cx = 1f
            cy = va / sa
        }
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(progVideo, "uTex"), 1, false, texMat, 0)
        GLES20.glUniform2f(GLES20.glGetUniformLocation(progVideo, "uCrop"), cx, cy)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, videoTex)
        GLES20.glUniform1i(GLES20.glGetUniformLocation(progVideo, "uSamp"), 0)
        quad(uvVideo)
    }

    private fun drawOverlay() {
        GLES20.glUseProgram(progOverlay)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE_MINUS_SRC_ALPHA) // bitmap is premultiplied
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, overlayTex)
        GLES20.glUniform1i(GLES20.glGetUniformLocation(progOverlay, "uSamp"), 0)
        quad(uvOverlay)
        GLES20.glDisable(GLES20.GL_BLEND)
    }

    private fun quad(uv: FloatBuffer) {
        GLES20.glEnableVertexAttribArray(0)
        GLES20.glVertexAttribPointer(0, 2, GLES20.GL_FLOAT, false, 8, quadPos)
        GLES20.glEnableVertexAttribArray(1)
        GLES20.glVertexAttribPointer(1, 2, GLES20.GL_FLOAT, false, 8, uv)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(0)
        GLES20.glDisableVertexAttribArray(1)
    }

    private fun uploadOverlay() {
        synchronized(lock) {
            val b = front
            if (!dirty || b == null || b.isRecycled) return
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, overlayTex)
            if (b.width != texW || b.height != texH) {
                GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, b, 0)
                texW = b.width
                texH = b.height
            } else {
                GLUtils.texSubImage2D(GLES20.GL_TEXTURE_2D, 0, 0, 0, b)
            }
            dirty = false
        }
    }

    private fun releaseAll() {
        closePlayer()
        if (eglDisplay != EGL14.EGL_NO_DISPLAY) {
            try {
                if (progVideo != 0) GLES20.glDeleteProgram(progVideo)
                if (progOverlay != 0) GLES20.glDeleteProgram(progOverlay)
                if (videoTex != 0) GLES20.glDeleteTextures(2, intArrayOf(videoTex, overlayTex), 0)
            } catch (_: Throwable) {
            }
            EGL14.eglMakeCurrent(eglDisplay, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
            if (eglSurface != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(eglDisplay, eglSurface)
            if (eglContext != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(eglDisplay, eglContext)
            EGL14.eglTerminate(eglDisplay)
        }
        eglDisplay = EGL14.EGL_NO_DISPLAY
        eglContext = EGL14.EGL_NO_CONTEXT
        eglSurface = EGL14.EGL_NO_SURFACE
        progVideo = 0
        progOverlay = 0
        videoTex = 0
        overlayTex = 0
        texW = 0
        texH = 0
    }
}
