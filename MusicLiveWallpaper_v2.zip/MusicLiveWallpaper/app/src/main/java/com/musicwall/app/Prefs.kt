package com.musicwall.app

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import org.json.JSONArray
import org.json.JSONObject

/** Wallpaper styles (order must match the `when` in MusicWallpaperService.render). */
object Styles {
    const val VINYL = 0
    const val BLUR_CARD = 1
    const val POSTER = 2
    const val WAVE = 3
    const val AURORA = 4
    const val EQ = 5
    const val GLASS = 6
    const val HYPER = 7
    const val LASERS = 8
    const val ORBITS = 9
    const val COUNT = 10

    val names = arrayOf(
        "Vinyl Disc",
        "Blur Card",
        "Full Poster",
        "Sound Waves",
        "Aurora",
        "Equalizer",
        "Liquid Glass",
        "Hyperspace",
        "Neon Lasers",
        "Orbits"
    )

    val descs = arrayOf(
        "Round cover spins like a record, with spectrum bars and rings around it",
        "Rounded cover over a blurred background, spectrum bars at the bottom",
        "Full-width cover fading into the background, spectrum at the bottom",
        "Layered waves at the bottom that move with the sound",
        "Soft drifting color lights that pulse with the bass",
        "Big mirrored equalizer bars in the middle of the screen",
        "Frosted jelly-glass panel with light sweeps and gel blobs",
        "Warp-speed star tunnel that accelerates on every beat",
        "Rotating neon laser beams and a glowing floor spectrum",
        "Planets orbiting the cover and leaving light trails"
    )
}

/** Automatic style switching modes. */
object AutoMode {
    const val OFF = 0
    const val PER_SONG = 1
    const val TIMED = 2

    val names = arrayOf(
        "Off",
        "Every new song",
        "Every 2 minutes"
    )
}

/** Ready-made color themes (used instead of colors taken from the album art). */
class Theme(val name: String, val accent: Int, val soft: Int, val bg: Int)

object Themes {
    val list = listOf(
        Theme("Violet–Cyan", Color.rgb(124, 92, 255), Color.rgb(64, 196, 255), Color.rgb(14, 12, 30)),
        Theme("Pink–Orange", Color.rgb(255, 92, 160), Color.rgb(255, 176, 80), Color.rgb(30, 10, 20)),
        Theme("Mint", Color.rgb(60, 230, 160), Color.rgb(80, 200, 255), Color.rgb(8, 24, 22)),
        Theme("Red–Gold", Color.rgb(255, 70, 70), Color.rgb(255, 200, 70), Color.rgb(28, 8, 8)),
        Theme("Minimal White", Color.rgb(240, 240, 245), Color.rgb(160, 170, 190), Color.rgb(10, 10, 12))
    )

    /** Index 0 = colors taken from the album art. */
    fun names(): List<String> = listOf("From album art") + list.map { it.name }
}

object BgMode {
    const val DEFAULT = 0   // gradient + blur from the cover
    const val BLACK = 1     // pure black
    const val IMAGE = 2     // picture from the gallery

    val names = listOf(
        "Blurred cover",
        "Pure black",
        "Gallery image"
    )
}

/** One song → video link. */
class VideoEntry(val key: String, val title: String, val artist: String, val uri: String)

/** Stores which video belongs to which song (JSON in SharedPreferences). */
object VideoLibrary {
    private val brackets = Regex("\\(.*?\\)|\\[.*?\\]")
    private val junk = Regex("[^\\p{L}\\p{M}\\p{N}]+")

    private fun norm(s: String): String =
        s.lowercase()
            .replace(brackets, " ")
            .replace(" - topic", " ")
            .replace(junk, " ")
            .trim()

    fun keyOf(title: String, artist: String): String = norm(title) + "|" + norm(artist)

    fun list(sp: SharedPreferences): List<VideoEntry> {
        val raw = sp.getString(Prefs.VIDEO_LIB, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                VideoEntry(o.getString("k"), o.optString("t"), o.optString("a"), o.getString("u"))
            }
        } catch (_: Throwable) {
            emptyList()
        }
    }

    private fun save(sp: SharedPreferences, items: List<VideoEntry>) {
        val arr = JSONArray()
        for (e in items) {
            arr.put(
                JSONObject().put("k", e.key).put("t", e.title).put("a", e.artist).put("u", e.uri)
            )
        }
        sp.edit().putString(Prefs.VIDEO_LIB, arr.toString()).apply()
    }

    fun put(sp: SharedPreferences, title: String, artist: String, uri: String) {
        val key = keyOf(title, artist)
        val items = list(sp).filter { it.key != key }.toMutableList()
        items.add(0, VideoEntry(key, title, artist, uri))
        save(sp, items)
    }

    fun remove(sp: SharedPreferences, key: String) {
        save(sp, list(sp).filter { it.key != key })
    }

    fun defaultUri(sp: SharedPreferences): String? = sp.getString(Prefs.VIDEO_DEFAULT, null)

    /** Video for the given song: exact match, then title-only match, then the default video. */
    fun resolve(sp: SharedPreferences, title: String, artist: String): String? {
        if (title.isNotBlank()) {
            val items = list(sp)
            val key = keyOf(title, artist)
            items.firstOrNull { it.key == key }?.let { return it.uri }
            val tn = norm(title)
            if (tn.isNotEmpty()) {
                val an = norm(artist)
                items.firstOrNull {
                    norm(it.title) == tn && (an.isEmpty() || norm(it.artist).isEmpty())
                }?.let { return it.uri }
            }
        }
        return defaultUri(sp)
    }
}

object Prefs {
    private const val FILE = "musicwall_prefs"
    const val STYLE = "style"
    const val AUTO = "auto"
    const val COLOR = "color"          // 0 = from cover, 1..N = ready-made theme
    const val INTENSITY = "intensity"  // 50..150 (%)
    const val COVER = "cover"          // 70..130 (%)
    const val PARTS = "parts"          // 0..100 (%)
    const val ROT = "rot"              // 0..200 (%)
    const val FX = "fx"                // 0..200 (%) beat flash / shake / sparks / shockwaves
    const val TEXT = "text"            // show title / artist
    const val BG = "bg"                // BgMode
    const val BGDIM = "bgdim"          // 0..85 (%)
    const val BGVER = "bgver"          // incremented whenever the background image changes
    const val BG_FILE = "custom_bg.jpg"

    const val VIDEO_ON = "video_on"            // play videos on the wallpaper
    const val VIDEO_DEFAULT = "video_default"  // content:// uri used for songs without their own video
    const val VIDEO_DIM = "video_dim"          // 0..80 (%)
    const val VIDEO_IDLE = "video_idle"        // keep video running while music is paused
    const val VIDEO_LIB = "video_lib"          // JSON list of VideoEntry
    const val PEND_TITLE = "pend_title"        // song waiting for a video pick
    const val PEND_ARTIST = "pend_artist"

    fun sp(ctx: Context): SharedPreferences =
        ctx.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun getInt(sp: SharedPreferences, key: String, def: Int): Int = sp.getInt(key, def)

    fun setInt(sp: SharedPreferences, key: String, v: Int) {
        sp.edit().putInt(key, v).apply()
    }

    fun style(sp: SharedPreferences): Int =
        sp.getInt(STYLE, Styles.VINYL).coerceIn(0, Styles.COUNT - 1)

    fun auto(sp: SharedPreferences): Int =
        sp.getInt(AUTO, AutoMode.OFF).coerceIn(0, 2)

    fun setStyle(sp: SharedPreferences, v: Int) = setInt(sp, STYLE, v)

    fun setAuto(sp: SharedPreferences, v: Int) = setInt(sp, AUTO, v)

    /** Restores every customization to its default (style, auto mode and videos are untouched). */
    fun resetCustom(sp: SharedPreferences) {
        sp.edit()
            .remove(COLOR).remove(INTENSITY).remove(COVER).remove(PARTS)
            .remove(ROT).remove(FX).remove(TEXT).remove(BG).remove(BGDIM)
            .remove(VIDEO_DIM).remove(VIDEO_IDLE)
            .apply()
    }
}
