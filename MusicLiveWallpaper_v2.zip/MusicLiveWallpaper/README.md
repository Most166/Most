# Music Live Wallpaper 2.0

Live wallpaper for Android 8.0+ that shows the album art of the song that is playing, with liquid-glass visuals,
beat-reactive animations and optional **video playback**.

## What's new in 2.0
- **Video wallpaper** - link a video file to any song (or set a default video). When that song plays, the video
  plays full screen behind the effects. Videos are muted; your music app keeps playing the sound. The video pauses
  with the music (optional: keep it running).
- **Crazy beat FX** on every style: zoom punch + screen shake, color flash, shockwave rings (with chromatic split),
  spark bursts, chromatic title split, falling peak caps on the spectrum bars. One slider (Beat FX 0-200%) controls them all
  (set it to 0 if you are sensitive to flashing).
- **4 new styles**: Liquid Glass, Hyperspace, Neon Lasers, Orbits (10 styles in total).
- **Liquid-glass app UI**: animated backdrop of glossy beads that follow your finger, frosted glass cards that blur
  what is behind them, jelly press animations, shimmering title, animated selection, fly-in entrance.
- Whole app is in English.

## Styles
| Style | Look |
|---|---|
| Vinyl Disc | Round cover spins like a record, spectrum bars and rings around it |
| Blur Card | Rounded cover over a blurred background, spectrum bars at the bottom |
| Full Poster | Full-width cover fading into the background |
| Sound Waves | Three layered waves at the bottom |
| Aurora | Soft drifting color lights that pulse with the bass |
| Equalizer | Big mirrored equalizer bars |
| Liquid Glass | Frosted jelly-glass panel with light sweeps and gel blobs |
| Hyperspace | Warp-speed star tunnel that accelerates on every beat |
| Neon Lasers | Rotating laser beams and a glowing floor spectrum |
| Orbits | Planets orbiting the cover with light trails |

Auto-switch: off / every new song / every 2 minutes (`AUTO_INTERVAL_MS`).

## Video wallpaper
1. Open the app -> **Video wallpaper** card.
2. Play a song in your music app, come back to this app, tap **Link a video to the current song** and pick a video.
   Repeat for other songs. Songs are matched by title and artist (brackets like "(Official Video)" are ignored).
3. Optionally choose a **default video** for every song that has none.
4. Adjust **Video dimming** so the effects stay readable.

Notes
- Videos are not copied: the app keeps permission to the file you picked, so don't delete or move it.
- Video is played with MediaPlayer + OpenGL ES; the effects are drawn into a transparent layer on top
  (at most 720px on the short side to stay smooth). Weak phones may prefer shorter / lower resolution videos.
- If a video cannot be played the wallpaper silently falls back to the normal effects.
- Style "Full Poster" automatically behaves like "Blur Card" while a video is playing.

## Customize (in the app)
Colors (from the cover or 5 themes), background (blurred cover / black / gallery image + dimming), effect intensity,
Beat FX, cover size, particle count, spin speed, show/hide title, reset button.

## Build with GitHub Actions (no Android Studio needed)
1. Create a new GitHub repo and upload everything in this folder (including `.github`).
2. Open the **Actions** tab -> workflow **Build APK** runs on push (or press **Run workflow**).
3. When it finishes (about 3-6 minutes) open the run -> **Artifacts** -> download `MusicLiveWallpaper-debug-apk`.
4. Unzip to get `app-debug.apk`, copy it to your phone and install.

## First-time setup on the phone
1. Open the app -> Setup -> enable **Notification access** (used to read the song and cover from music apps).
   - If the switch is greyed out: App info -> three dots -> "Allow restricted settings", then enable it again.
2. (Optional) Allow the microphone so effects react to the real audio through the Visualizer API.
   The app never records audio. Without it, effects use a simulated beat.
3. Tap **Set as live wallpaper** and confirm.
4. Play music in any app (Spotify, YouTube Music, ...).

## Code map
| File | Purpose |
|---|---|
| `MediaListenerService.kt` | Reads song / cover from MediaSession (NotificationListenerService) |
| `MusicState.kt` | State shared between the services and the UI |
| `MusicWallpaperService.kt` | Draws the wallpaper: styles, beat FX, Palette colors, Visualizer, video switching |
| `VideoGl.kt` | EGL/OpenGL ES video player + overlay compositor (own thread) |
| `Prefs.kt` | Style list, themes, video library (song -> video), settings keys |
| `GlassKit.kt` | Liquid-glass UI components (backdrop, panels, rows, chips, buttons) |
| `MainActivity.kt` | The settings screen |

Add a new style: add a constant + name/description in `Styles` (`Prefs.kt`), write a `drawXxx` function and add a
branch to `when (eff)` in `MusicWallpaperService.render`. Set `fxX` / `fxY` inside it so shockwaves and sparks
come out of the right spot.
